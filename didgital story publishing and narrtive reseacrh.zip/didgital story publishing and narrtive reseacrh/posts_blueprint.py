from flask import Blueprint, render_template, redirect, url_for, flash, request, abort
from flask_login import login_required, current_user
from extensions import db
from models import Post, Comment, Bookmark, Like, Report, ReadHistory, make_slug
from datetime import datetime
import json, re

posts_bp = Blueprint('posts', __name__)

CATEGORIES = ['Technology','Design','Science','Culture','Travel','Health','Business','General']

def ai_analyze_post(post):
    body_lower = post.body.lower() + ' ' + post.title.lower()
    flags, score = [], 100
    if len(re.findall(r'http[s]?://', post.body)) > 3:
        flags.append('excessive_links'); score -= 20
    if post.body.count('!') > 10:
        flags.append('excessive_exclamation'); score -= 10
    if len(re.findall(r'[A-Z]{4,}', post.body)) > 5:
        flags.append('excessive_caps'); score -= 15
    word_count = len(post.body.split())
    if word_count < 50:
        flags.append('too_short'); score -= 25
    elif word_count > 100: score += 5
    bad_words = ['spam', 'scam', 'hack', 'illegal', 'drugs']
    if any(w in body_lower for w in bad_words):
        flags.append('flagged_keywords'); score -= 30
    positive = sum(1 for w in ['great','good','excellent','amazing','helpful','learn'] if w in body_lower)
    negative = sum(1 for w in ['terrible','awful','hate','worst','horrible'] if w in body_lower)
    sentiment = 'positive' if positive > negative else ('negative' if negative > positive else 'neutral')
    score = max(0, min(100, score))
    critical = {'flagged_keywords', 'excessive_links'}
    auto_approve = score >= 70 and not any(f in critical for f in flags)
    summary = (f"Word count: {word_count}. Quality score: {score}/100. "
               + (f"Flags: {', '.join(flags).replace('_',' ')}. " if flags else '')
               + f"Sentiment: {sentiment}. "
               + ("✅ Recommended for auto-approval." if auto_approve else "⚠️ Requires manual review."))
    return {'score': score, 'flags': flags, 'sentiment': sentiment, 'summary': summary, 'auto_approve': auto_approve}

def add_notification(user_id, message, type='info', link=''):
    from models import Notification
    db.session.add(Notification(user_id=user_id, message=message, type=type, link=link))
    db.session.commit()

@posts_bp.route('/')
def index():
    page = request.args.get('page', 1, type=int)
    category = request.args.get('category', '')
    search = request.args.get('q', '').strip()
    query = Post.query.filter_by(status='published').order_by(Post.created_at.desc())
    if category: query = query.filter_by(category=category)
    if search: query = query.filter(db.or_(Post.title.ilike(f'%{search}%'), Post.body.ilike(f'%{search}%'), Post.tags.ilike(f'%{search}%')))
    posts = query.paginate(page=page, per_page=10)
    latest = Post.query.filter_by(status='published').order_by(Post.created_at.desc()).limit(3).all()
    trending = Post.query.filter_by(status='published').order_by(Post.view_count.desc()).limit(5).all()
    return render_template('index.html', posts=posts, latest=latest, categories=CATEGORIES,
                           current_category=category, trending=trending, search=search)

@posts_bp.route('/post/<slug>')
def post_detail(slug):
    post = Post.query.filter_by(slug=slug).first_or_404()
    if post.status != 'published' and (not current_user.is_authenticated or
       (current_user.id != post.user_id and not current_user.is_admin)): abort(404)
    post.view_count = (post.view_count or 0) + 1
    db.session.commit()
    if current_user.is_authenticated:
        rh = ReadHistory.query.filter_by(user_id=current_user.id, post_id=post.id).first()
        if rh:
            rh.last_read_at = datetime.utcnow(); rh.read_count += 1
        else:
            db.session.add(ReadHistory(user_id=current_user.id, post_id=post.id))
        db.session.commit()
    related = Post.query.filter(Post.category==post.category, Post.id!=post.id,
                                Post.status=='published').order_by(Post.created_at.desc()).limit(3).all()
    is_bookmarked = is_liked = False
    if current_user.is_authenticated:
        is_bookmarked = Bookmark.query.filter_by(user_id=current_user.id, post_id=post.id).first() is not None
        is_liked = Like.query.filter_by(user_id=current_user.id, post_id=post.id).first() is not None
    return render_template('post_detail.html', post=post, related=related, is_bookmarked=is_bookmarked, is_liked=is_liked)

@posts_bp.route('/post/new', methods=['GET', 'POST'])
@login_required
def new_post():
    if current_user.is_admin:
        flash('Admins manage the site. Use a user account to write posts.', 'error')
        return redirect(url_for('admin.dashboard'))
    if current_user.is_banned:
        flash('Your account has been banned from publishing.', 'error')
        return redirect(url_for('posts.index'))
    if request.method == 'POST':
        title = request.form.get('title','').strip()
        body  = request.form.get('body','').strip()
        category = request.form.get('category','General')
        excerpt  = request.form.get('excerpt','').strip() or body[:200]+'...'
        tags     = request.form.get('tags','').strip()
        action   = request.form.get('action','submit')
        if not title or not body:
            flash('Title and content are required.', 'error')
            return render_template('post_form.html', categories=CATEGORIES, form=request.form)
        if action == 'draft':
            post = Post(title=title, slug=make_slug(title), body=body, excerpt=excerpt,
                        category=category, user_id=current_user.id, tags=tags, status='draft')
            db.session.add(post); db.session.commit()
            flash('Draft saved!', 'success')
            return redirect(url_for('user.my_drafts'))
        post = Post(title=title, slug=make_slug(title), body=body, excerpt=excerpt,
                    category=category, user_id=current_user.id, tags=tags, status='pending')
        db.session.add(post); db.session.flush()
        analysis = ai_analyze_post(post)
        post.ai_score = analysis['score']; post.ai_flags = json.dumps(analysis['flags'])
        post.ai_summary = analysis['summary']; post.ai_sentiment = analysis['sentiment']
        if analysis['auto_approve']:
            post.status = 'published'; post.reviewed_at = datetime.utcnow()
            db.session.commit()
            add_notification(current_user.id, f'✅ Your story "{title}" was auto-approved and is now live!',
                type='success', link=url_for('posts.post_detail', slug=post.slug))
            flash('Story published! It passed automatic review.', 'success')
        else:
            db.session.commit()
            add_notification(current_user.id, f'📋 Your story "{title}" is under review by our team.', type='info')
            flash('Story submitted! Our team will review it shortly.', 'info')
        return redirect(url_for('auth.profile', username=current_user.username))
    return render_template('post_form.html', categories=CATEGORIES, form={})

@posts_bp.route('/post/<slug>/edit', methods=['GET', 'POST'])
@login_required
def edit_post(slug):
    post = Post.query.filter_by(slug=slug).first_or_404()
    if current_user.is_admin: flash('Admins cannot edit posts.','error'); return redirect(url_for('admin.dashboard'))
    if post.author != current_user: abort(403)
    if request.method == 'POST':
        post.title = request.form.get('title','').strip()
        post.body  = request.form.get('body','').strip()
        post.category = request.form.get('category','General')
        post.excerpt  = request.form.get('excerpt','').strip() or post.body[:200]+'...'
        post.tags = request.form.get('tags','').strip()
        post.updated_at = datetime.utcnow(); post.status = 'pending'
        analysis = ai_analyze_post(post)
        post.ai_score = analysis['score']; post.ai_flags = json.dumps(analysis['flags'])
        post.ai_summary = analysis['summary']; post.ai_sentiment = analysis['sentiment']
        if analysis['auto_approve']: post.status = 'published'; post.reviewed_at = datetime.utcnow()
        db.session.commit()
        flash('Post updated and resubmitted for review.', 'success')
        return redirect(url_for('posts.post_detail', slug=post.slug))
    return render_template('post_form.html', categories=CATEGORIES, post=post, form=post)

@posts_bp.route('/post/<slug>/delete', methods=['POST'])
@login_required
def delete_post(slug):
    post = Post.query.filter_by(slug=slug).first_or_404()
    if post.author != current_user and not current_user.is_admin: abort(403)
    db.session.delete(post); db.session.commit()
    flash('Post deleted.', 'success')
    return redirect(url_for('posts.index'))

@posts_bp.route('/post/<slug>/comment', methods=['POST'])
@login_required
def add_comment(slug):
    post = Post.query.filter_by(slug=slug).first_or_404()
    body = request.form.get('body','').strip()
    if not body: flash('Comment cannot be empty.','error')
    else:
        db.session.add(Comment(body=body, user_id=current_user.id, post_id=post.id))
        db.session.commit()
        if post.author.id != current_user.id:
            add_notification(post.author.id, f'💬 {current_user.username} commented on "{post.title}"',
                type='info', link=url_for('posts.post_detail', slug=slug))
        flash('Comment added!', 'success')
    return redirect(url_for('posts.post_detail', slug=slug)+'#comments')

@posts_bp.route('/comment/<int:comment_id>/delete', methods=['POST'])
@login_required
def delete_comment(comment_id):
    comment = Comment.query.get_or_404(comment_id)
    if comment.author != current_user and not current_user.is_admin: abort(403)
    slug = comment.post.slug
    db.session.delete(comment); db.session.commit()
    flash('Comment deleted.', 'success')
    return redirect(url_for('posts.post_detail', slug=slug)+'#comments')

@posts_bp.route('/post/<slug>/bookmark', methods=['POST'])
@login_required
def toggle_bookmark(slug):
    post = Post.query.filter_by(slug=slug).first_or_404()
    bm = Bookmark.query.filter_by(user_id=current_user.id, post_id=post.id).first()
    if bm: db.session.delete(bm); db.session.commit(); flash('Bookmark removed.','info')
    else: db.session.add(Bookmark(user_id=current_user.id, post_id=post.id)); db.session.commit(); flash('Bookmarked!','success')
    return redirect(url_for('posts.post_detail', slug=slug))

@posts_bp.route('/post/<slug>/like', methods=['POST'])
@login_required
def toggle_like(slug):
    post = Post.query.filter_by(slug=slug).first_or_404()
    lk = Like.query.filter_by(user_id=current_user.id, post_id=post.id).first()
    if lk: db.session.delete(lk); db.session.commit()
    else: db.session.add(Like(user_id=current_user.id, post_id=post.id)); db.session.commit()
    return redirect(url_for('posts.post_detail', slug=slug))

@posts_bp.route('/post/<slug>/report', methods=['POST'])
@login_required
def report_post(slug):
    post = Post.query.filter_by(slug=slug).first_or_404()
    reason = request.form.get('reason','').strip()
    if reason:
        db.session.add(Report(reporter_id=current_user.id, post_id=post.id, reason=reason))
        db.session.commit(); flash('Report submitted. Thank you.','success')
    return redirect(url_for('posts.post_detail', slug=slug))

@posts_bp.route('/tags/<tag>')
def tag_posts(tag):
    page = request.args.get('page', 1, type=int)
    posts = Post.query.filter(Post.tags.ilike(f'%{tag}%'), Post.status=='published').paginate(page=page, per_page=10)
    return render_template('tag.html', posts=posts, tag=tag)

@posts_bp.route('/search')
def search():
    q = request.args.get('q', '').strip()
    if not q: return redirect(url_for('posts.index'))
    return redirect(url_for('posts.index', q=q))


# ── Extra routes referenced in base.html ─────────────────────────────────────

@posts_bp.route('/tags')
def tags():
    from models import Post
    all_tags = []
    for p in Post.query.filter_by(status='published').all():
        if p.tags:
            all_tags.extend([t.strip() for t in p.tags.split(',') if t.strip()])
    tag_counts = {}
    for t in all_tags:
        tag_counts[t] = tag_counts.get(t, 0) + 1
    return render_template('tags.html', tag_counts=tag_counts)

@posts_bp.route('/leaderboard')
def leaderboard():
    from models import User
    from extensions import db
    top = db.session.query(User).order_by(User.id).limit(20).all()
    return render_template('leaderboard.html', users=top)

@posts_bp.route('/writing-prompts')
def writing_prompts():
    return render_template('drafts.html', posts=[], title='Writing Prompts')

@posts_bp.route('/drafts')
@login_required
def drafts():
    from models import Post
    posts = Post.query.filter_by(user_id=current_user.id, status='draft').order_by(Post.created_at.desc()).all()
    return render_template('drafts.html', posts=posts)

@posts_bp.route('/following')
@login_required
def following():
    return render_template('following.html')

@posts_bp.route('/reading-history')
@login_required
def reading_history():
    from models import ReadHistory
    history = ReadHistory.query.filter_by(user_id=current_user.id).order_by(ReadHistory.read_at.desc()).limit(50).all()
    return render_template('reading_history.html', history=history)

@posts_bp.route('/ai-assistant')
@login_required
def ai_assistant():
    return render_template('ai_assistant.html')

@posts_bp.route('/research-assistant')
@login_required
def research_assistant():
    return render_template('research_assistant.html')

@posts_bp.route('/references')
@login_required
def references():
    from models import Reference
    refs = Reference.query.filter_by(user_id=current_user.id).all()
    return render_template('references.html', references=refs)

@posts_bp.route('/focus-timer')
@login_required
def focus_timer():
    return render_template('focus_timer.html')

@posts_bp.route('/content-calendar')
@login_required
def content_calendar():
    from models import CalendarItem
    items = CalendarItem.query.filter_by(user_id=current_user.id).all()
    return render_template('content_calendar.html', items=items)

@posts_bp.route('/challenges')
@login_required
def challenges():
    return render_template('challenges.html')

@posts_bp.route('/collections')
@login_required
def collections():
    from models import Collection
    cols = Collection.query.filter_by(user_id=current_user.id).all()
    return render_template('collections.html', collections=cols)

@posts_bp.route('/mood-board')
@login_required
def mood_board():
    return render_template('mood_board.html')

@posts_bp.route('/writing-goals')
@login_required
def writing_goals():
    from models import WritingGoal
    goals = WritingGoal.query.filter_by(user_id=current_user.id).all()
    return render_template('collections.html', collections=goals)

@posts_bp.route('/post/<slug>/like', methods=['POST'])
@login_required
def like_post(slug):
    return toggle_like(slug)

@posts_bp.route('/user/follow/<username>', methods=['POST'])
@login_required
def follow_user(username):
    from models import User, Follow, Notification
    target = User.query.filter_by(username=username).first_or_404()
    existing = Follow.query.filter_by(follower_id=current_user.id, followed_id=target.id).first()
    if existing:
        db.session.delete(existing)
        db.session.commit()
        return jsonify({'following': False, 'message': f'Unfollowed {username}'})
    follow = Follow(follower_id=current_user.id, followed_id=target.id)
    db.session.add(follow)
    db.session.commit()
    return jsonify({'following': True, 'message': f'Now following {username}'})

@posts_bp.route('/reading-history/clear', methods=['POST'])
@login_required
def clear_reading_history():
    from models import ReadHistory
    ReadHistory.query.filter_by(user_id=current_user.id).delete()
    db.session.commit()
    flash('Reading history cleared.', 'success')
    return redirect(url_for('posts.reading_history'))

@posts_bp.route('/collections/<int:col_id>/delete', methods=['POST'])
@login_required
def delete_collection(col_id):
    from models import Collection
    col = Collection.query.get_or_404(col_id)
    if col.user_id != current_user.id:
        abort(403)
    db.session.delete(col)
    db.session.commit()
    flash('Collection deleted.', 'success')
    return redirect(url_for('posts.collections'))

@posts_bp.route('/post/<slug>/publish', methods=['POST'])
@login_required
def publish_draft(slug):
    post = Post.query.filter_by(slug=slug, user_id=current_user.id).first_or_404()
    post.status = 'pending'
    db.session.commit()
    flash('Post submitted for review!', 'success')
    return redirect(url_for('posts.post_detail', slug=slug))
