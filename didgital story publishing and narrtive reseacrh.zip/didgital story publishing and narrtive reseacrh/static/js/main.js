// Auto-dismiss flash messages after 5s
document.querySelectorAll('.flash').forEach(f => {
  setTimeout(() => { if(f.parentElement) f.style.opacity='0'; setTimeout(()=>f.remove(),300); }, 5000);
});

// Smooth scroll for anchor links
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const el = document.querySelector(a.getAttribute('href'));
    if(el){ e.preventDefault(); el.scrollIntoView({behavior:'smooth', block:'start'}); }
  });
});

// Confirm dialogs for delete forms (extra safety)
document.querySelectorAll('form[onsubmit]').forEach(f => {
  // already handled inline
});

// Animate stat numbers on scroll
const observeStats = () => {
  const stats = document.querySelectorAll('.admin-stat-num, .stat-num');
  const io = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if(e.isIntersecting){ e.target.style.opacity='1'; e.target.style.transform='translateY(0)'; }
    });
  }, {threshold:.2});
  stats.forEach(s => { s.style.opacity='0'; s.style.transform='translateY(8px)'; s.style.transition='opacity .4s, transform .4s'; io.observe(s); });
};
if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', observeStats);
else observeStats();
