@echo off
:: PASTE YOUR GROQ API KEY HERE (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)
set GROQ_API_KEY=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
set VIDRUSH_API_KEY=PASTE_VIDRUSH_KEY_HERE
echo FFmpeg must be installed: https://ffmpeg.org/download.html
echo.
echo Installing dependencies...
pip install -r requirements.txt -q
echo.
echo Starting server...
echo Open: http://127.0.0.1:5000
echo.
python app.py
pause
