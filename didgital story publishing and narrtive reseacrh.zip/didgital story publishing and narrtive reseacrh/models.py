from datetime import datetime
import json
import re
from flask_login import UserMixin
from extensions import db

class User(db.Model, UserMixin):
    __tablename__ = 'users'
    id            = db.Column(db.Integer, primary_key=True)
    username      = db.Column(db.String(30), unique=True, nullable=False)
    email         = db.Column(db.String(120), unique=True, nullable=False)
    password      = db.Column(db.String(200), nullable=False)
    bio           = db.Column(db.Text, default='')
    is_admin      = db.Column(db.Boolean, default=False, nullable=False)
    is_banned     = db.Column(db.Boolean, default=False, nullable=False)
    joined_at     = db.Column(db.DateTime, default=datetime.utcnow)
    posts         = db.relationship('Post', foreign_keys='Post.user_id', backref='author', lazy=True, cascade='all, delete-orphan')
    comments      = db.relationship('Comment', backref='author', lazy=True, cascade='all, delete-orphan')
    bookmarks     = db.relationship('Bookmark', backref='user', lazy=True, cascade='all, delete-orphan')
    notifications = db.relationship('Notification', backref='user', lazy=True, cascade='all, delete-orphan')

    @property
    def initials(self): return self.username[:2].upper()
    @property
    def post_count(self): return Post.query.filter_by(user_id=self.id, status='published').count()
    @property
    def unread_notifications(self): return Notification.query.filter_by(user_id=self.id, is_read=False).count()

class Post(db.Model):
    __tablename__ = 'posts'
    id            = db.Column(db.Integer, primary_key=True)
    title         = db.Column(db.String(200), nullable=False)
    slug          = db.Column(db.String(220), unique=True, nullable=False)
    body          = db.Column(db.Text, nullable=False)
    excerpt       = db.Column(db.String(300), nullable=False, default='')
    category      = db.Column(db.String(50), default='General')
    tags          = db.Column(db.String(200), default='')
    created_at    = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at    = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    user_id       = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    status        = db.Column(db.String(20), default='pending')
    ai_score      = db.Column(db.Integer, default=0)
    ai_flags      = db.Column(db.Text, default='[]')
    ai_summary    = db.Column(db.Text, default='')
    ai_sentiment  = db.Column(db.String(20), default='neutral')
    reviewed_at   = db.Column(db.DateTime, nullable=True)
    reviewed_by   = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    reject_reason = db.Column(db.Text, default='')
    view_count    = db.Column(db.Integer, default=0)
    comments      = db.relationship('Comment', backref='post', lazy=True, cascade='all, delete-orphan')
    bookmarks     = db.relationship('Bookmark', backref='post', lazy=True, cascade='all, delete-orphan')

    @property
    def comment_count(self): return len(self.comments)
    @property
    def like_count(self): return Like.query.filter_by(post_id=self.id).count()
    @property
    def reading_time(self):
        return f"{max(1, round(len(self.body.split()) / 200))} min read"
    @property
    def tag_list(self): return [t.strip() for t in self.tags.split(',') if t.strip()] if self.tags else []
    @property
    def ai_flags_list(self):
        try: return json.loads(self.ai_flags or '[]')
        except: return []

class Comment(db.Model):
    __tablename__ = 'comments'
    id         = db.Column(db.Integer, primary_key=True)
    body       = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    user_id    = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    post_id    = db.Column(db.Integer, db.ForeignKey('posts.id'), nullable=False)

class Bookmark(db.Model):
    __tablename__ = 'bookmarks'
    id         = db.Column(db.Integer, primary_key=True)
    user_id    = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    post_id    = db.Column(db.Integer, db.ForeignKey('posts.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Notification(db.Model):
    __tablename__ = 'notifications'
    id         = db.Column(db.Integer, primary_key=True)
    user_id    = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    message    = db.Column(db.Text, nullable=False)
    type       = db.Column(db.String(20), default='info')
    link       = db.Column(db.String(300), default='')
    is_read    = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class SiteSettings(db.Model):
    __tablename__ = 'site_settings'
    id    = db.Column(db.Integer, primary_key=True)
    key   = db.Column(db.String(80), unique=True, nullable=False)
    value = db.Column(db.Text, default='')

class Report(db.Model):
    __tablename__ = 'reports'
    id          = db.Column(db.Integer, primary_key=True)
    reporter_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    post_id     = db.Column(db.Integer, db.ForeignKey('posts.id'), nullable=True)
    reason      = db.Column(db.String(200), nullable=False)
    status      = db.Column(db.String(20), default='open')
    created_at  = db.Column(db.DateTime, default=datetime.utcnow)

class LoginHistory(db.Model):
    __tablename__ = 'login_history'
    id         = db.Column(db.Integer, primary_key=True)
    user_id    = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    ip_address = db.Column(db.String(45), default='')
    user_agent = db.Column(db.String(300), default='')
    status     = db.Column(db.String(20), default='success')   # success | failed | banned
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    user       = db.relationship('User', backref=db.backref('login_history', lazy=True, cascade='all, delete-orphan'))

class Follow(db.Model):
    __tablename__ = 'follows'
    id          = db.Column(db.Integer, primary_key=True)
    follower_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    followed_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    created_at  = db.Column(db.DateTime, default=datetime.utcnow)
    __table_args__ = (db.UniqueConstraint('follower_id', 'followed_id'),)
    follower = db.relationship('User', foreign_keys=[follower_id], backref=db.backref('following', lazy=True, cascade='all, delete-orphan'))
    followed = db.relationship('User', foreign_keys=[followed_id], backref=db.backref('followers', lazy=True, cascade='all, delete-orphan'))

class Like(db.Model):
    __tablename__ = 'likes'
    id         = db.Column(db.Integer, primary_key=True)
    user_id    = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    post_id    = db.Column(db.Integer, db.ForeignKey('posts.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    __table_args__ = (db.UniqueConstraint('user_id', 'post_id'),)

class ReadHistory(db.Model):
    __tablename__ = 'read_history'
    id           = db.Column(db.Integer, primary_key=True)
    user_id      = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    post_id      = db.Column(db.Integer, db.ForeignKey('posts.id'), nullable=False)
    last_read_at = db.Column(db.DateTime, default=datetime.utcnow)
    read_count   = db.Column(db.Integer, default=1)
    __table_args__ = (db.UniqueConstraint('user_id', 'post_id'),)
    user = db.relationship('User', backref=db.backref('read_history', lazy=True, cascade='all, delete-orphan'))
    post = db.relationship('Post', backref=db.backref('read_by', lazy=True, cascade='all, delete-orphan'))

class Collection(db.Model):
    __tablename__ = 'collections'
    id          = db.Column(db.Integer, primary_key=True)
    user_id     = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    name        = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, default='')
    created_at  = db.Column(db.DateTime, default=datetime.utcnow)
    user        = db.relationship('User', backref=db.backref('collections', lazy=True, cascade='all, delete-orphan'))
    items       = db.relationship('CollectionItem', backref='collection', lazy=True, cascade='all, delete-orphan')

class CollectionItem(db.Model):
    __tablename__ = 'collection_items'
    id            = db.Column(db.Integer, primary_key=True)
    collection_id = db.Column(db.Integer, db.ForeignKey('collections.id'), nullable=False)
    post_id       = db.Column(db.Integer, db.ForeignKey('posts.id'), nullable=False)
    added_at      = db.Column(db.DateTime, default=datetime.utcnow)
    post          = db.relationship('Post')

class WritingGoal(db.Model):
    __tablename__ = 'writing_goals'
    id         = db.Column(db.Integer, primary_key=True)
    user_id    = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    title      = db.Column(db.String(100), nullable=False)
    target     = db.Column(db.Integer, nullable=False)
    unit       = db.Column(db.String(20), default='posts')  # posts / words / days
    deadline   = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    done       = db.Column(db.Boolean, default=False)
    user       = db.relationship('User', backref=db.backref('writing_goals', lazy=True, cascade='all, delete-orphan'))

class AuditLog(db.Model):
    __tablename__ = 'audit_log'
    id         = db.Column(db.Integer, primary_key=True)
    user_id    = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    action     = db.Column(db.String(200), nullable=False)
    detail     = db.Column(db.Text, default='')
    ip_address = db.Column(db.String(45), default='')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    user       = db.relationship('User', backref=db.backref('audit_logs', lazy=True))

class ContentFilter(db.Model):
    __tablename__ = 'content_filters'
    id         = db.Column(db.Integer, primary_key=True)
    pattern    = db.Column(db.String(200), nullable=False)
    action     = db.Column(db.String(20), default='flag')  # flag / block
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Reference(db.Model):
    __tablename__ = 'user_references'
    id         = db.Column(db.Integer, primary_key=True)
    user_id    = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    title      = db.Column(db.String(300), nullable=False)
    authors    = db.Column(db.String(300), default='')
    year       = db.Column(db.String(10), default='')
    journal    = db.Column(db.String(200), default='')
    doi        = db.Column(db.String(200), default='')
    url        = db.Column(db.String(500), default='')
    ref_type   = db.Column(db.String(30), default='article')
    notes      = db.Column(db.Text, default='')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    user       = db.relationship('User', backref=db.backref('references', lazy=True, cascade='all, delete-orphan'))

    def format_citation(self, style='apa'):
        a = self.authors or 'Unknown Author'
        y = f"({self.year})" if self.year else ''
        t = self.title
        j = self.journal
        d = f"https://doi.org/{self.doi}" if self.doi else self.url or ''
        if style == 'apa':
            return f"{a} {y}. {t}. {j}. {d}".strip('. ')
        elif style == 'mla':
            return f"{a}. \"{t}.\" {j} {self.year}. {d}".strip()
        elif style == 'chicago':
            return f"{a}. \"{t}.\" {j} ({self.year}). {d}".strip()
        return f"{a} ({self.year}). {t}. {j}."

class CalendarItem(db.Model):
    __tablename__ = 'calendar_items'
    id           = db.Column(db.Integer, primary_key=True)
    user_id      = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    title        = db.Column(db.String(200), nullable=False)
    content_type = db.Column(db.String(50), default='article')
    scheduled_at = db.Column(db.DateTime, nullable=False)
    notes        = db.Column(db.Text, default='')
    status       = db.Column(db.String(20), default='planned')
    created_at   = db.Column(db.DateTime, default=datetime.utcnow)
    user         = db.relationship('User', backref=db.backref('calendar_items', lazy=True, cascade='all, delete-orphan'))

def make_slug(title):
    slug = re.sub(r'[^\w\s-]', '', title.lower().strip())
    slug = re.sub(r'[\s_-]+', '-', slug)
    slug = re.sub(r'^-+|-+$', '', slug)
    base, counter = slug, 1
    while Post.query.filter_by(slug=slug).first():
        slug = f"{base}-{counter}"; counter += 1
    return slug
