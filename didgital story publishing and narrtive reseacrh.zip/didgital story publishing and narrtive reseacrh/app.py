"""
Inkwell – Digital Story Publishing Platform
app.py  (blueprint-based factory)
"""
import os
from datetime import datetime, timezone
from flask import Flask, render_template
from dotenv import load_dotenv

load_dotenv()

from extensions import db, bcrypt, login_manager, jwt, csrf, limiter


def create_app(config_override=None):
    app = Flask(__name__)

    BASE_DIR = os.path.abspath(os.path.dirname(__file__))
    database_url = os.environ.get('DATABASE_URL', f"sqlite:///{os.path.join(BASE_DIR, 'inkwell.db')}")
    if database_url.startswith("postgres://"):
        database_url = database_url.replace("postgres://", "postgresql://", 1)

    app.config.update(
        SECRET_KEY=os.environ.get('SECRET_KEY', 'dev-secret-change-in-prod'),
        SQLALCHEMY_DATABASE_URI=database_url,
        SQLALCHEMY_TRACK_MODIFICATIONS=False,
        JWT_SECRET_KEY=os.environ.get('JWT_SECRET_KEY', 'dev-jwt-secret'),
        WTF_CSRF_ENABLED=True,
        WTF_CSRF_TIME_LIMIT=3600,
        MAX_CONTENT_LENGTH=50 * 1024 * 1024,
    )
    if config_override:
        app.config.update(config_override)

    db.init_app(app)
    bcrypt.init_app(app)
    login_manager.init_app(app)
    jwt.init_app(app)
    csrf.init_app(app)
    limiter.init_app(app)

    login_manager.login_view = 'auth.login'
    login_manager.login_message = 'Please log in to access this page.'
    login_manager.login_message_category = 'info'

    @app.after_request
    def set_security_headers(response):
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'SAMEORIGIN'
        response.headers['X-XSS-Protection'] = '1; mode=block'
        response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
        response.headers['Content-Security-Policy'] = (
            "default-src 'self'; "
            "script-src 'self' 'unsafe-inline' cdn.jsdelivr.net cdnjs.cloudflare.com; "
            "style-src 'self' 'unsafe-inline' fonts.googleapis.com cdn.jsdelivr.net cdnjs.cloudflare.com; "
            "font-src 'self' fonts.gstatic.com; "
            "img-src * data: blob:; "
            "media-src 'self' blob:; "
            "connect-src 'self';"
        )
        return response

    from models import User
    @login_manager.user_loader
    def load_user(user_id):
        return db.session.get(User, int(user_id))

    @app.template_filter('timeago')
    def timeago(dt):
        if not dt:
            return 'unknown'
        now = datetime.now(timezone.utc)
        dt_aware = dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt
        diff = now - dt_aware
        if diff.days > 365: return f"{diff.days // 365}y ago"
        if diff.days > 30:  return f"{diff.days // 30}mo ago"
        if diff.days > 0:   return f"{diff.days}d ago"
        hours = diff.seconds // 3600
        if hours > 0:       return f"{hours}h ago"
        minutes = diff.seconds // 60
        return f"{minutes}m ago" if minutes > 0 else "just now"

    from auth_blueprint      import auth_bp
    from posts_blueprint     import posts_bp
    from admin_blueprint     import admin_bp
    from api_blueprint       import api_bp
    from video_blueprint     import video_bp, create_video_tables
    from multiwork_blueprint import multiwork_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(posts_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(api_bp)
    csrf.exempt(api_bp)
    app.register_blueprint(video_bp)
    app.register_blueprint(multiwork_bp)

    @app.errorhandler(404)
    def not_found(e):
        return render_template('error.html', code=404, message='Page not found'), 404

    @app.errorhandler(403)
    def forbidden(e):
        return render_template('error.html', code=403, message='Access forbidden'), 403

    @app.errorhandler(429)
    def ratelimited(e):
        return render_template('error.html', code=429, message='Too many requests'), 429

    with app.app_context():
        db.create_all()
        create_video_tables()
        _seed()

    return app


def _seed():
    from models import User, Post, Comment, make_slug
    if User.query.first():
        return
    hashed = bcrypt.generate_password_hash('admin123').decode('utf-8')
    admin = User(username='admin', email='admin@inkwell.com', password=hashed,
                 is_admin=True, bio='Inkwell administrator.')
    db.session.add(admin); db.session.flush()
    hashed2 = bcrypt.generate_password_hash('password123').decode('utf-8')
    demo = User(username='inkwell', email='demo@inkwell.com', password=hashed2,
                bio='The Inkwell demo account.')
    db.session.add(demo); db.session.flush()
    for title, cat, body, excerpt in [
        ('The Art of Deep Work', 'Technology',
         'Deep work is the ability to focus without distraction on a cognitively demanding task. '
         'It is a skill that allows you to quickly master complicated information and produce better '
         'results in less time. The research shows that professionals who can perform deep work are '
         'becoming increasingly rare, yet increasingly valuable in our distracted economy.',
         'Deep work is the ability to focus without distraction...'),
        ('Design Systems at Scale', 'Design',
         'A design system is a collection of reusable components guided by clear standards that can '
         'be assembled to build any number of applications. The most successful design systems combine '
         'tokens, components, and documentation in a way that empowers every member of the team.',
         'A design system is the single source of truth...'),
    ]:
        p = Post(title=title, slug=make_slug(title), body=body, excerpt=excerpt,
                 category=cat, user_id=demo.id, status='published', view_count=42)
        db.session.add(p); db.session.flush()
        db.session.add(Comment(body='Great article!', user_id=demo.id, post_id=p.id))
    db.session.commit()
    print("Seeded: admin@inkwell.com / admin123 | demo@inkwell.com / password123")


app = create_app()

if __name__ == '__main__':
    app.run(debug=os.environ.get('FLASK_DEBUG', '1') == '1')
