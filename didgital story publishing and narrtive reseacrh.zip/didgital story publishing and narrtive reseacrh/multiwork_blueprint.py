from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required
import os

multiwork_bp = Blueprint('multiwork', __name__, url_prefix='/multiwork')

def _get_groq():
    from groq import Groq
    key = os.environ.get('GROQ_API_KEY', '')
    if not key: return None
    return Groq(api_key=key)

@multiwork_bp.route('/')
@login_required
def index():
    return render_template('multiwork/index.html')

@multiwork_bp.route('/business-ideas')
@login_required
def business_ideas():
    return render_template('multiwork/business_ideas.html')

@multiwork_bp.route('/content-ideas')
@login_required
def content_ideas():
    return render_template('multiwork/content_ideas.html')

@multiwork_bp.route('/cricbuzz')
@login_required
def cricbuzz():
    return render_template('multiwork/cricbuzz.html')

@multiwork_bp.route('/chatbot')
@login_required
def chatbot():
    q = request.args.get('q', '')
    return render_template('multiwork/chatbot.html', initial_q=q)

# ─── Research Courses Data ───────────────────────────────────────────────────
RESEARCH_CATEGORIES = [
    "Academic Writing", "Data Science", "AI & ML", "Business Research",
    "Social Science", "Scientific Methodology", "Marketing Research",
    "UX/UI Research", "Health Research", "Environmental Research"
]

# ─── MIT OpenCourseWare Integration ──────────────────────────────────────────
# MIT OCW has 2500+ courses. We map key departments to stable Archive.org IDs.

RESEARCH_CATEGORIES = [
    "Computer Science", "Mathematics", "Physics", "Economics",
    "Management", "Engineering", "Biology & Health",
    "Humanities & Social Science", "Architecture & Planning", "General Research"
]

# Mapping real MIT Department prefixes to stable Archive.org Course IDs
DEPARTMENT_COURSES = {
    "Computer Science": [
        {"id": "mit6_0001f16", "title": "Introduction to Computer Science"},
        {"id": "MIT6.006S20", "title": "Introduction to Algorithms"},
        {"id": "mit6_7960f24", "title": "Deep Learning Fundamentals"}
    ],
    "Mathematics": [
        {"id": "MIT18.06S05", "title": "Linear Algebra"},
        {"id": "MIT18.01S07", "title": "Single Variable Calculus"}
    ],
    "Physics": [
        {"id": "MIT8.01S99", "title": "Classical Mechanics (Walter Lewin)"},
        {"id": "MIT8.02S02", "title": "Electricity and Magnetism"}
    ],
    "Economics": [
        {"id": "MIT14.01SCF11", "title": "Principles of Microeconomics"},
        {"id": "MIT14.31_F15", "title": "Data Analysis for Social Scientists"}
    ],
    "Management": [
        {"id": "MIT15.053F13", "title": "Optimization Methods in Management"},
        {"id": "MIT15.071S17", "title": "The Analytics Edge"}
    ],
    "Humanities & Social Science": [
        {"id": "MIT21W.035_F16", "title": "Science Writing and New Media"},
        {"id": "MIT17.801_F15", "title": "Political Science Scope and Methods"}
    ],
    "General Research": [
        {"id": "MITRES.18-001S11", "title": "Calculus Revisited"},
        {"id": "qualitative-research-methods-interview-process", "title": "Qualitative Research Methods"}
    ]
}

def _generate_courses():
    courses = []

    # 1. Add Featured Real MIT Courses first
    id_counter = 1
    for cat, items in DEPARTMENT_COURSES.items():
        for item in items:
            courses.append({
                "id": id_counter,
                "title": f"MIT {item['title']}",
                "category": cat,
                "duration": "12-15 Hours",
                "lessons_count": 24,
                "description": f"Official MIT OpenCourseWare curriculum for {item['title']}. Master fundamental concepts from the world's leading technical institution.",
                "archive_id": item['id'],
                "is_featured": True
            })
            id_counter += 1

    # 2. Generate the rest to reach 250, simulating the 2500+ library
    topics = [
        "Foundations of {cat}", "Advanced {cat} Techniques", "{cat} for Professionals",
        "Modern Trends in {cat}", "Ethics in {cat}", "{cat} Case Studies",
        "Mastering {cat} Analytics", "Qualitative {cat} Methods", "Quantitative {cat} Tools",
        "The Future of {cat}", "Digital {cat} Frameworks", "Critical Thinking in {cat}",
        "Big Data in {cat}", "{cat} in the 21st Century", "Strategic {cat} Design",
        "Applied {cat} Workshop", "{cat} Publishing 101", "Literature Review for {cat}",
        "Effective {cat} Communication", "{cat} for Startups", "Collaborative {cat} Models",
        "Open Science in {cat}", "{cat} Software & Tools", "Experimental Design for {cat}",
        "Global Perspectives on {cat}", "Sustainable {cat} Development"
    ]

    while len(courses) < 250:
        for cat in RESEARCH_CATEGORIES:
            topic_tpl = topics[id_counter % len(topics)]
            title = topic_tpl.format(cat=cat)

            # Find a fallback archive ID for the category
            fallback_id = DEPARTMENT_COURSES.get(cat, [{"id": "mit6_0001f16"}])[0]['id']

            courses.append({
                "id": id_counter,
                "title": title,
                "category": cat,
                "duration": f"{id_counter % 5 + 2} Hours",
                "lessons_count": 5 + (id_counter % 8),
                "description": f"A comprehensive study module focusing on {title}. Part of the extended research library.",
                "archive_id": fallback_id,
                "is_featured": False
            })
            id_counter += 1
            if len(courses) >= 250: break

    return courses

@multiwork_bp.route('/courses')
@login_required
def courses_list():
    all_courses = _generate_courses()
    cat_filter = request.args.get('category', '')
    if cat_filter:
        all_courses = [c for c in all_courses if c['category'] == cat_filter]
    return render_template('multiwork/courses_list.html', courses=all_courses, categories=RESEARCH_CATEGORIES, current_cat=cat_filter)

@multiwork_bp.route('/course/<int:course_id>')
@login_required
def play_course(course_id):
    all_courses = _generate_courses()
    course = next((c for c in all_courses if c['id'] == course_id), None)
    if not course: return "Course not found", 404

    lessons = []
    if course.get('archive_id'):
        for i in range(1, course['lessons_count'] + 1):
            lessons.append({
                "title": f"Lesson {i}: " + (course['title'] if i==1 else f"Module {i}"),
                "type": "video",
                "duration": f"{10 + i}m",
                "archive_id": course['archive_id'],
                "index": i
            })
    else:
        video_files = ["job_1.mp4", "job_3.mp4", "job_4.mp4", "job_5.mp4"]
        for i in range(1, course['lessons_count'] + 1):
            lessons.append({
                "title": f"Lesson {i}: Module {i}",
                "type": "video" if i % 2 != 0 else "reading",
                "duration": "15m",
                "video_url": url_for('static', filename=f"videos/{video_files[i % len(video_files)]}") if i % 2 != 0 else None
            })

    return render_template('multiwork/course_player.html', course=course, lessons=lessons)

@multiwork_bp.route('/chat', methods=['POST'])
@login_required
def chat():
    user_msg = request.json.get('message', '')
    client = _get_groq()
    if not client:
        return jsonify({'response': "GROQ_API_KEY not set. Please set it to use the chatbot."})

    try:
        resp = client.chat.completions.create(
            model='llama-3.1-8b-instant',
            messages=[
                {'role': 'system', 'content': 'You are Inkwell ChatGPT, an expert AI assistant integrated into the Inkwell story platform. You are helpful, creative, and professional. You specialize in entrepreneurship, content creation, and storytelling.'},
                {'role': 'user', 'content': user_msg}
            ],
            temperature=0.7
        )
        return jsonify({'response': resp.choices[0].message.content})
    except Exception as e:
        error_msg = str(e)
        if "401" in error_msg or "invalid_api_key" in error_msg:
            return jsonify({'response': "⚠️ **Invalid API Key detected.**\n\nPlease open your `run.bat` file and ensure you have pasted a valid Groq API key in the `set GROQ_API_KEY=` line, then restart the server."})
        return jsonify({'response': f"Error: {error_msg}"})
