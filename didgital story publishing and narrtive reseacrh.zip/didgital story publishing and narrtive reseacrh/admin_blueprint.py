from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from extensions import db
from models import User, Post, Comment, Report, AuditLog, ContentFilter
from datetime import datetime, timedelta
from functools import wraps

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not current_user.is_authenticated:
            return redirect(url_for('auth.login', next=request.url))
        if not current_user.is_admin:
            from flask import abort
            abort(403)
        return f(*args, **kwargs)
    return decorated

def add_notification(user_id, message, type='info', link=''):
    from models import Notification
    db.session.add(Notification(user_id=user_id, message=message, type=type, link=link))
    db.session.commit()

def log_audit(action, detail=''):
    ip = request.headers.get('X-Forwarded-For', request.remote_addr or '').split(',')[0].strip()
    db.session.add(AuditLog(user_id=current_user.id if current_user.is_authenticated else None,
                            action=action, detail=detail, ip_address=ip))
    db.session.commit()

def get_setting(key, default=''):
    from models import SiteSettings
    s = SiteSettings.query.filter_by(key=key).first()
    return s.value if s else default

def set_setting(key, value):
    from models import SiteSettings
    s = SiteSettings.query.filter_by(key=key).first()
    if s: s.value = value
    else: db.session.add(SiteSettings(key=key, value=value))
    db.session.commit()

CATEGORIES = ['Technology','Design','Science','Culture','Travel','Health','Business','General']

@admin_bp.route('/')
@admin_required
def dashboard():
    total_users = User.query.count()
    total_posts = Post.query.filter_by(status='published').count()
    total_pending = Post.query.filter_by(status='pending').count()
    total_comments = Comment.query.count()
    total_admins = User.query.filter_by(is_admin=True).count()
    total_reports = Report.query.filter_by(status='open').count()
    recent_posts = Post.query.order_by(Post.created_at.desc()).limit(5).all()
    recent_users = User.query.order_by(User.joined_at.desc()).limit(5).all()
    pending_posts = Post.query.filter_by(status='pending').order_by(Post.created_at.asc()).all()
    category_stats = [{'name':c,'count':Post.query.filter_by(category=c,status='published').count()}
                      for c in CATEGORIES if Post.query.filter_by(category=c,status='published').count()]
    return render_template('admin/dashboard.html', total_users=total_users, total_posts=total_posts,
        total_pending=total_pending, total_comments=total_comments, total_admins=total_admins,
        total_reports=total_reports, recent_posts=recent_posts, recent_users=recent_users,
        pending_posts=pending_posts, category_stats=category_stats)

@admin_bp.route('/review')
@admin_required
def review():
    pending = Post.query.filter_by(status='pending').order_by(Post.created_at.asc()).all()
    return render_template('admin/review.html', pending=pending)

@admin_bp.route('/review/<int:post_id>/approve', methods=['POST'])
@admin_required
def approve_post(post_id):
    post = Post.query.get_or_404(post_id)
    post.status = 'published'; post.reviewed_at = datetime.utcnow(); post.reviewed_by = current_user.id
    db.session.commit()
    add_notification(post.user_id, f'✅ Your story "{post.title}" has been approved and is now live!',
        type='success', link=url_for('posts.post_detail', slug=post.slug))
    flash(f'Story approved and published.', 'success')
    return redirect(url_for('admin.review'))

@admin_bp.route('/review/<int:post_id>/reject', methods=['POST'])
@admin_required
def reject_post(post_id):
    post = Post.query.get_or_404(post_id)
    reason = request.form.get('reason','Does not meet content guidelines.').strip()
    post.status = 'rejected'; post.reviewed_at = datetime.utcnow()
    post.reviewed_by = current_user.id; post.reject_reason = reason
    db.session.commit()
    add_notification(post.user_id, f'❌ Your story "{post.title}" was not approved. Reason: {reason}', type='danger')
    flash('Story rejected.', 'success')
    return redirect(url_for('admin.review'))

@admin_bp.route('/posts')
@admin_required
def posts():
    page=request.args.get('page',1,type=int); search=request.args.get('q','').strip()
    category=request.args.get('category',''); status=request.args.get('status','')
    query = Post.query.order_by(Post.created_at.desc())
    if search: query = query.filter(Post.title.ilike(f'%{search}%'))
    if category: query = query.filter_by(category=category)
    if status: query = query.filter_by(status=status)
    posts = query.paginate(page=page, per_page=15)
    return render_template('admin/posts.html', posts=posts, search=search,
        categories=CATEGORIES, current_category=category, current_status=status)

@admin_bp.route('/posts/<int:post_id>/delete', methods=['POST'])
@admin_required
def delete_post(post_id):
    post = Post.query.get_or_404(post_id); title = post.title
    db.session.delete(post); db.session.commit()
    flash(f'Post "{title}" deleted.','success')
    return redirect(url_for('admin.posts'))

@admin_bp.route('/users')
@admin_required
def users():
    page=request.args.get('page',1,type=int); search=request.args.get('q','').strip()
    query = User.query.order_by(User.joined_at.desc())
    if search: query = query.filter(db.or_(User.username.ilike(f'%{search}%'),User.email.ilike(f'%{search}%')))
    users = query.paginate(page=page, per_page=15)
    return render_template('admin/users.html', users=users, search=search)

@admin_bp.route('/users/<int:user_id>/toggle-admin', methods=['POST'])
@admin_required
def toggle_admin(user_id):
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id: flash('You cannot change your own admin status.','error'); return redirect(url_for('admin.users'))
    user.is_admin = not user.is_admin; db.session.commit()
    flash(f'Admin status updated for {user.username}.','success')
    return redirect(url_for('admin.users'))

@admin_bp.route('/users/<int:user_id>/toggle-ban', methods=['POST'])
@admin_required
def toggle_ban(user_id):
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id: flash('You cannot ban yourself.','error'); return redirect(url_for('admin.users'))
    user.is_banned = not user.is_banned; db.session.commit()
    add_notification(user.id, f'Your account has been {"suspended" if user.is_banned else "restored"}.', type='danger' if user.is_banned else 'success')
    flash(f'User {"banned" if user.is_banned else "unbanned"}.','success')
    return redirect(url_for('admin.users'))

@admin_bp.route('/users/<int:user_id>/delete', methods=['POST'])
@admin_required
def delete_user(user_id):
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id: flash('You cannot delete yourself.','error'); return redirect(url_for('admin.users'))
    username = user.username; db.session.delete(user); db.session.commit()
    flash(f'User "{username}" deleted.','success')
    return redirect(url_for('admin.users'))

@admin_bp.route('/comments')
@admin_required
def comments():
    page=request.args.get('page',1,type=int)
    comments = Comment.query.order_by(Comment.created_at.desc()).paginate(page=page,per_page=20)
    return render_template('admin/comments.html', comments=comments)

@admin_bp.route('/comments/<int:comment_id>/delete', methods=['POST'])
@admin_required
def delete_comment(comment_id):
    comment = Comment.query.get_or_404(comment_id)
    db.session.delete(comment); db.session.commit()
    flash('Comment deleted.','success')
    return redirect(url_for('admin.comments'))

@admin_bp.route('/reports')
@admin_required
def reports():
    page=request.args.get('page',1,type=int)
    reports = Report.query.order_by(Report.created_at.desc()).paginate(page=page,per_page=20)
    return render_template('admin/reports.html', reports=reports)

@admin_bp.route('/reports/<int:report_id>/resolve', methods=['POST'])
@admin_required
def resolve_report(report_id):
    report = Report.query.get_or_404(report_id)
    report.status = 'resolved'; db.session.commit()
    flash('Report resolved.','success')
    return redirect(url_for('admin.reports'))

@admin_bp.route('/analytics')
@admin_required
def analytics():
    days = []
    for i in range(13,-1,-1):
        d = datetime.utcnow() - timedelta(days=i)
        count = Post.query.filter(Post.created_at>=d.replace(hour=0,minute=0,second=0),
            Post.created_at<d.replace(hour=23,minute=59,second=59), Post.status=='published').count()
        days.append({'date':d.strftime('%b %d'),'count':count})
    top_posts = Post.query.filter_by(status='published').order_by(Post.view_count.desc()).limit(10).all()
    category_stats = [{'name':c,'count':Post.query.filter_by(category=c,status='published').count()} for c in CATEGORIES]
    approval_stats = {
        'published': Post.query.filter_by(status='published').count(),
        'pending':   Post.query.filter_by(status='pending').count(),
        'rejected':  Post.query.filter_by(status='rejected').count()
    }
    return render_template('admin/analytics.html', days=days, top_posts=top_posts,
        category_stats=category_stats, approval_stats=approval_stats)

@admin_bp.route('/settings', methods=['GET','POST'])
@admin_required
def settings():
    if request.method == 'POST':
        for key in ['site_name','site_tagline','auto_approve','maintenance_mode','allow_registration','posts_per_page']:
            set_setting(key, request.form.get(key,''))
        flash('Settings saved!','success')
        return redirect(url_for('admin.settings'))
    settings = {
        'site_name': get_setting('site_name','Inkwell'),
        'site_tagline': get_setting('site_tagline','Where ideas find their voice'),
        'auto_approve': get_setting('auto_approve','on'),
        'maintenance_mode': get_setting('maintenance_mode','off'),
        'allow_registration': get_setting('allow_registration','on'),
        'posts_per_page': get_setting('posts_per_page','6'),
    }
    return render_template('admin/settings.html', settings=settings)

@admin_bp.route("/audit-log")
@admin_required
def audit_log():
    logs = AuditLog.query.order_by(AuditLog.created_at.desc()).limit(200).all()
    return render_template("admin/audit_log.html", logs=logs)

@admin_bp.route("/email-broadcast", methods=["GET", "POST"])
@admin_required
def broadcast():
    sent = False
    if request.method == "POST":
        subject = request.form.get("subject","").strip()
        body    = request.form.get("body","").strip()
        target  = request.form.get("target","all")
        if subject and body:
            users = User.query.filter_by(is_banned=False).all() if target=="all" else User.query.filter_by(is_admin=True).all()
            for u in users:
                add_notification(u.id, f"📣 {subject}", type="info")
            log_audit("email_broadcast", f"Subject: {subject} | Target: {target} | Recipients: {len(users)}")
            flash(f"Broadcast sent to {len(users)} users as notifications!","success")
            sent = True
    user_count  = User.query.filter_by(is_banned=False).count()
    admin_count = User.query.filter_by(is_admin=True).count()
    return render_template("admin/email_broadcast.html", sent=sent, user_count=user_count, admin_count=admin_count)

@admin_bp.route("/content-filter", methods=["GET", "POST"])
@admin_required
def content_filter():
    if request.method == "POST":
        action = request.form.get("action")
        if action == "add":
            pattern = request.form.get("pattern","").strip().lower()
            act     = request.form.get("filter_action","flag")
            if pattern:
                db.session.add(ContentFilter(pattern=pattern, action=act))
                db.session.commit()
                log_audit("content_filter_added", pattern)
                flash("Filter added.","success")
        elif action == "delete":
            f = ContentFilter.query.get(int(request.form.get("filter_id")))
            if f: db.session.delete(f); db.session.commit(); flash("Filter removed.","success")
        return redirect(url_for("admin.content_filter"))
    filters = ContentFilter.query.order_by(ContentFilter.created_at.desc()).all()
    return render_template("admin/content_filter.html", filters=filters)

@admin_bp.route("/monetization")
@admin_required
def monetization():
    from sqlalchemy import func
    total_users  = User.query.count()
    total_posts  = Post.query.filter_by(status="published").count()
    total_views  = db.session.query(func.sum(Post.view_count)).scalar() or 0
    top_posts    = Post.query.filter_by(status="published").order_by(Post.view_count.desc()).limit(5).all()
    top_authors  = db.session.query(User, func.count(Post.id).label("pc"))\
        .join(Post, Post.user_id==User.id).filter(Post.status=="published")\
        .group_by(User.id).order_by(db.text("pc desc")).limit(5).all()
    return render_template("admin/monetization.html",
        total_users=total_users, total_posts=total_posts, total_views=total_views,
        top_posts=top_posts, top_authors=top_authors)

@admin_bp.route("/ai-moderation")
@admin_required
def ai_moderation():
    flagged   = Post.query.filter(Post.ai_flags != "[]", Post.ai_flags != None)\
        .order_by(Post.created_at.desc()).limit(50).all()
    low_score = Post.query.filter(Post.ai_score < 50).order_by(Post.ai_score.asc()).limit(20).all()
    avg_score = db.session.query(db.func.avg(Post.ai_score)).scalar() or 0
    return render_template("admin/ai_moderation.html",
        flagged=flagged, low_score=low_score, avg_score=round(avg_score,1))
