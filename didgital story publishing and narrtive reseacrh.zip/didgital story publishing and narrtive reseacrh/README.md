# ✒️ Inkwell — Digital Story Publishing Platform

[![CI](https://github.com/YOUR_USERNAME/inkwell/actions/workflows/ci.yml/badge.svg)](https://github.com/YOUR_USERNAME/inkwell/actions/workflows/ci.yml)
[![Python 3.10](https://img.shields.io/badge/python-3.10-blue.svg)](https://python.org)
[![Flask](https://img.shields.io/badge/flask-3.0-green.svg)](https://flask.palletsprojects.com)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

Inkwell is a full-stack digital story publishing platform where writers can publish articles, generate AI story videos, and collaborate on narratives. Built with Flask, SQLite, Groq AI, and FFmpeg.

---

## 🚀 Features

| Feature | Tech |
|---|---|
| Auth (register / login / JWT) | Flask-Login + Flask-JWT-Extended |
| AI content moderation | Groq API (llama-3.1-8b-instant) |
| Story-to-video pipeline | Pollinations.ai + gTTS + FFmpeg |
| Collaborative writing | multiwork_blueprint |
| REST API | `/api/*` endpoints with JWT |
| Admin dashboard | Review, approve, reject, analytics |
| Security | CSRF, rate limiting, bleach, CSP headers |
| CI/CD | GitHub Actions → pytest |

---

## 📁 Project Structure

```
inkwell/
├── app.py                   # App factory — registers all blueprints
├── extensions.py            # db, bcrypt, jwt, csrf, limiter singletons
├── models.py                # SQLAlchemy models
├── auth_blueprint.py        # /register /login /logout /profile
├── posts_blueprint.py       # / /post/<slug> /post/new /search ...
├── admin_blueprint.py       # /admin/* routes
├── api_blueprint.py         # /api/* REST endpoints (JWT)
├── video_blueprint.py       # /video/* story-to-video pipeline
├── multiwork_blueprint.py   # /multiwork/* collaborative writing
├── requirements.txt
├── Procfile                 # Render / Heroku deploy
├── render.yaml              # Render.com blueprint
├── .env.example             # Required environment variables
├── .github/workflows/ci.yml # GitHub Actions CI
└── tests/
    ├── conftest.py          # pytest fixtures
    ├── test_auth.py         # 11 auth tests
    ├── test_posts.py        # 8 post/interaction tests
    └── test_admin.py        # 16 admin + REST API tests
```

---

## ⚙️ Local Setup

```bash
# 1. Clone
git clone https://github.com/YOUR_USERNAME/inkwell.git
cd inkwell

# 2. Create virtual environment
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Configure environment
cp .env.example .env
# Edit .env and add your GROQ_API_KEY

# 5. Run
python app.py
# → http://localhost:5000
# → Admin: admin@inkwell.com / admin123
```

---

## 🧪 Running Tests

```bash
pytest tests/ -v
```

Expected output:
```
40 passed, 1 skipped in ~8s
```

---

## 🌐 REST API Reference

All endpoints return JSON. Authenticated endpoints require:
```
Authorization: Bearer <JWT_TOKEN>
```

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | `/api/posts?page=1&limit=10` | No | Paginated published posts |
| GET | `/api/post/<id>` | No | Single post with comments |
| POST | `/api/register` | No | Register → JWT token |
| POST | `/api/login` | No | Login → JWT token |
| POST | `/api/post` | ✅ JWT | Create post |
| GET | `/api/user/<username>` | No | Public user profile |

### Example: Register + Create Post
```bash
# Register
curl -X POST http://localhost:5000/api/register \
  -H "Content-Type: application/json" \
  -d '{"username":"alice","email":"alice@example.com","password":"secret123"}'

# Response
{"token": "eyJ...", "user": {"username": "alice", ...}}

# Create post
curl -X POST http://localhost:5000/api/post \
  -H "Authorization: Bearer eyJ..." \
  -H "Content-Type: application/json" \
  -d '{"title":"My Story","body":"Long body text here...","category":"Technology"}'
```

---

## 🚢 Deploying to Render.com (Free)

### Step-by-step

1. **Push to GitHub**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin https://github.com/YOUR_USERNAME/inkwell.git
   git push -u origin main
   ```

2. **Create Render account** → [render.com](https://render.com) → Sign up free

3. **New Web Service**
   - Dashboard → **New** → **Web Service**
   - Connect your GitHub repo

4. **Configure**
   | Setting | Value |
   |---|---|
   | Runtime | Python 3 |
   | Build Command | `pip install -r requirements.txt` |
   | Start Command | `gunicorn app:app --workers 2 --bind 0.0.0.0:$PORT` |
   | Plan | Free |

5. **Set Environment Variables** (Dashboard → Environment tab)
   ```
   SECRET_KEY        → (click Generate)
   JWT_SECRET_KEY    → (click Generate)
   GROQ_API_KEY      → gsk_xxxxxxxxxxxx
   FLASK_ENV         → production
   ```

6. **Deploy** → Render auto-deploys on every `git push`

> **Note:** Render free tier spins down after 15 min of inactivity. The first request after sleep takes ~30s.

---

## 🔒 Security Features

- **CSRF protection** — Flask-WTF on all POST forms
- **Rate limiting** — 5 req/min on `/login` and `/register` (Flask-Limiter)
- **Input sanitization** — bleach strips XSS from all user HTML before DB save
- **CSP headers** — Content-Security-Policy via `after_request`
- **Upload validation** — MIME type check + 50MB size cap on video uploads
- **Env secrets** — All keys via `os.environ` / `.env`, never hardcoded

---

## 🤖 AI Features

### Content Moderation (Groq API)
Every submitted post is automatically analysed for:
- Quality score (0–100)
- Sentiment (positive / neutral / negative)
- Flags (spam, hate speech, too short, etc.)
- AI summary

### Story-to-Video Pipeline
1. Groq generates scene descriptions from your story
2. Pollinations.ai renders each scene as an image
3. gTTS converts narration to MP3
4. FFmpeg combines images + audio into an MP4

---

## 📊 GitHub Actions CI Badge

Add this to the top of your README (replace `YOUR_USERNAME`):

```markdown
[![CI](https://github.com/YOUR_USERNAME/inkwell/actions/workflows/ci.yml/badge.svg)](https://github.com/YOUR_USERNAME/inkwell/actions/workflows/ci.yml)
```

---

## 👤 Default Accounts (Development Only)

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@inkwell.com | admin123 |
| Demo user | demo@inkwell.com | password123 |

> These are seeded automatically on first run. **Change them in production.**

---

## 📄 License

MIT © 2025 Inkwell
