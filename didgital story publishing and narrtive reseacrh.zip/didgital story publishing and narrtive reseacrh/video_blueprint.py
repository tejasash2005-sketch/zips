"""
Inkwell — Story-to-Video Module
================================
Blueprint: video_bp   prefix: /video

Dependencies (add to requirements.txt):
    groq>=0.9
    gTTS>=2.5
    requests>=2.31
    ffmpeg  (system binary — `apt install ffmpeg` or brew)

Env vars:
    GROQ_API_KEY   — Groq API key (https://console.groq.com)
"""

from flask import Blueprint, render_template, redirect, url_for, flash, request, abort, jsonify, send_file, current_app
from flask_login import login_required, current_user
from datetime import datetime
import os, json, threading, subprocess, tempfile, textwrap, re, math, urllib.parse, urllib.request, time, concurrent.futures

# ── Blueprint ─────────────────────────────────────────────────────────────────
video_bp = Blueprint('video', __name__, url_prefix='/video')

# ── Lazy imports (only loaded when actually used) ─────────────────────────────
def _gtts():
    from gtts import gTTS
    return gTTS

def _groq_client():
    from groq import Groq
    key = os.environ.get('GROQ_API_KEY', '')
    return Groq(api_key=key) if key else None

def _vidrush_config():
    return {
        'api_key': os.environ.get('VIDRUSH_API_KEY', ''),
        'enabled': bool(os.environ.get('VIDRUSH_API_KEY', '').strip())
    }

# ── Models (imported at call-time to avoid circular import) ───────────────────
def _db():
    from extensions import db
    return db

def _models():
    from extensions import db
    from models import Post
    return db, Post

# ─────────────────────────────────────────────────────────────────────────────
# Database Models
# ─────────────────────────────────────────────────────────────────────────────
from extensions import db

class VideoJob(db.Model):
    __tablename__ = 'video_jobs'
    id          = db.Column(db.Integer, primary_key=True)
    post_id     = db.Column(db.Integer, db.ForeignKey('posts.id'), nullable=False)
    user_id     = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    status      = db.Column(db.String(20), default='queued')   # queued|processing|done|failed
    total_scenes= db.Column(db.Integer, default=0)
    done_scenes = db.Column(db.Integer, default=0)
    created_at  = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at  = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    post        = db.relationship('Post', backref=db.backref('video_jobs', lazy=True))
    scenes      = db.relationship('VideoScene', backref='job', lazy=True, cascade='all, delete-orphan')
    output      = db.relationship('VideoOutput', backref='job', uselist=False, cascade='all, delete-orphan')

    @property
    def progress_percent(self):
        if self.total_scenes == 0:
            return 0
        return min(100, int(self.done_scenes / self.total_scenes * 100))

class VideoScene(db.Model):
    __tablename__ = 'video_scenes'
    id               = db.Column(db.Integer, primary_key=True)
    job_id           = db.Column(db.Integer, db.ForeignKey('video_jobs.id'), nullable=False)
    scene_number     = db.Column(db.Integer, nullable=False)
    image_prompt     = db.Column(db.Text, default='')
    video_prompt     = db.Column(db.Text, default='')
    narration_text   = db.Column(db.Text, default='')
    character_details = db.Column(db.Text, default='')
    environment_details = db.Column(db.Text, default='')
    duration_seconds = db.Column(db.Integer, default=8)
    image_path       = db.Column(db.String(300), default='')
    audio_path       = db.Column(db.String(300), default='')
    subtitle_start   = db.Column(db.Float, default=0.0)
    status           = db.Column(db.String(20), default='pending')

class VideoOutput(db.Model):
    __tablename__ = 'video_outputs'
    id           = db.Column(db.Integer, primary_key=True)
    job_id       = db.Column(db.Integer, db.ForeignKey('video_jobs.id'), nullable=False)
    file_path    = db.Column(db.String(300), default='')
    file_size_mb = db.Column(db.Float, default=0.0)
    view_count   = db.Column(db.Integer, default=0)
    created_at   = db.Column(db.DateTime, default=datetime.utcnow)

class VideoFailedJob(db.Model):
    __tablename__ = 'video_failed_jobs'
    id            = db.Column(db.Integer, primary_key=True)
    job_id        = db.Column(db.Integer, db.ForeignKey('video_jobs.id'), nullable=False)
    error_message = db.Column(db.Text, default='')
    failed_at     = db.Column(db.DateTime, default=datetime.utcnow)


def create_video_tables():
    """Call once from app startup to ensure video tables exist."""
    db.create_all()


# ─────────────────────────────────────────────────────────────────────────────
# Scene Generation (Groq)
# ─────────────────────────────────────────────────────────────────────────────
def _chunk_text(text: str, max_words: int = 500) -> list[str]:
    words = text.split()
    chunks = []
    for i in range(0, len(words), max_words):
        chunks.append(' '.join(words[i:i + max_words]))
    return chunks

_SCENE_SYSTEM = textwrap.dedent("""
    You are an Expert AI Cinematographer and Director.
    Your task is to convert this story into a high-end visual masterpiece.

    GUIDELINES:
    1. BREAK the story into frequent, short scenes (every 10-20 words of narration).
    2. IMAGE PROMPT: Describe a cinematic shot. Include style, lighting, and composition.
    3. VIDEO PROMPT: Describe the motion in the scene (e.g., 'gentle zoom in', 'slow pan left', 'character smiles').
    4. CHARACTER CONSISTENCY: Describe the main characters in the scene consistently.
    5. ENVIRONMENT: Describe the background details.
    6. NARRATION: The exact text to be spoken.

    Return ONLY a JSON array of objects with these exact keys:
      scene_number, narration, image_prompt, video_prompt, character_details, environment_details, duration_seconds.
""").strip()

def generate_scenes(post_body: str, post_title: str, job_id: int) -> list[dict]:
    """
    Call Groq to break the story into scenes.
    Handles long stories by chunking.
    """
    client = _groq_client()
    # Chunk by ~800 words to give enough context but fit in prompt
    chunks = _chunk_text(post_body, max_words=800)
    all_scenes = []
    offset = 0

    if not client:
        # Fallback if no API key
        for chunk in chunks:
            sentences = re.split(r'(?<=[.!?])\s+', chunk)
            for i, sent in enumerate(sentences):
                sent = sent.strip()
                if len(sent) < 15: continue
                all_scenes.append({
                    'scene_number': offset + 1,
                    'image_prompt': f"Cinematic shot of {sent[:100]}",
                    'video_prompt': "Slow camera movement",
                    'narration': sent,
                    'character_details': "Consistent character design",
                    'environment_details': "Detailed background",
                    'duration_seconds': max(5, min(15, len(sent.split()) // 2))
                })
                offset += 1
                if offset >= 200: break
    else:
        for chunk in chunks:
            prompt = f"Story title: {post_title}\n\nContent:\n{chunk}\n\nScene offset: {offset}"
            try:
                resp = client.chat.completions.create(
                    model='llama-3.1-70b-versatile', # Use larger model for better consistency
                    messages=[
                        {'role': 'system', 'content': _SCENE_SYSTEM},
                        {'role': 'user',   'content': prompt},
                    ],
                    response_format={"type": "json_object"} if "llama-3.1" in "llama-3.1-70b-versatile" else None,
                    max_tokens=4000,
                    temperature=0.7,
                )
                raw = resp.choices[0].message.content.strip()
                # If the model didn't return a JSON array directly, try to find it
                if not raw.startswith('['):
                    match = re.search(r'\[.*\]', raw, re.DOTALL)
                    if match: raw = match.group(0)

                scenes = json.loads(raw)
                if isinstance(scenes, dict) and 'scenes' in scenes:
                    scenes = scenes['scenes']

                if isinstance(scenes, list):
                    all_scenes.extend(scenes)
                    offset = len(all_scenes)
            except Exception as e:
                print(f"Groq error: {e}")
                # Simple fallback for this chunk
                sentences = re.split(r'(?<=[.!?])\s+', chunk)
                for sent in sentences:
                    if len(sent.strip()) > 10:
                        all_scenes.append({
                            'scene_number': offset + 1,
                            'narration': sent.strip(),
                            'image_prompt': f"Cinematic: {sent[:80]}",
                            'video_prompt': "Subtle motion",
                            'duration_seconds': 8
                        })
                        offset += 1
            if offset >= 250: break # Production cap for 1-hour target

    # Persist to DB
    for s in all_scenes:
        scene = VideoScene(
            job_id=job_id,
            scene_number=int(s.get('scene_number', 1)),
            image_prompt=str(s.get('image_prompt', '')),
            video_prompt=str(s.get('video_prompt', '')),
            narration_text=str(s.get('narration', s.get('narration_text', ''))),
            character_details=str(s.get('character_details', '')),
            environment_details=str(s.get('environment_details', '')),
            duration_seconds=max(3, min(20, int(s.get('duration_seconds', 8)))),
        )
        db.session.add(scene)
    db.session.commit()
    return all_scenes


# ─────────────────────────────────────────────────────────────────────────────
# AI Visual Generation (Video & Image)
# ─────────────────────────────────────────────────────────────────────────────
def _download_visual(prompt: str, out_path: str, use_video=True) -> bool:
    """
    Attempts to download a real AI video clip or image.
    Uses Pollinations.ai (Free/Unlimited) with enhanced cinematic prompts.
    """
    # Enhance prompt for production look
    enhanced_prompt = f"{prompt}, cinematic lighting, 8k, highly detailed, masterwork, masterpiece, trending on artstation"
    encoded = urllib.parse.quote(enhanced_prompt)

    # 1. Try Video generation (Pollinations Seedance)
    if use_video:
        video_url = f'https://gen.pollinations.ai/video/{encoded}?model=seedance&nologo=true&seed={int(time.time())}'
        try:
            req = urllib.request.Request(video_url, headers={'User-Agent': 'Inkwell/3.0'})
            with urllib.request.urlopen(req, timeout=120) as resp:
                data = resp.read()
                if len(data) > 10000:
                    with open(out_path, 'wb') as f:
                        f.write(data)
                    return True
        except Exception as e:
            print(f"Video gen error: {e}")

    # 2. Try Image generation (Flux) - Reliable High Quality
    img_url = f'https://image.pollinations.ai/prompt/{encoded}?width=1280&height=720&nologo=true&model=flux'
    try:
        img_path = out_path.replace('.mp4', '.jpg')
        req = urllib.request.Request(img_url, headers={'User-Agent': 'Inkwell/3.0'})
        with urllib.request.urlopen(req, timeout=60) as resp:
            data = resp.read()
            if len(data) > 1000:
                with open(img_path, 'wb') as f:
                    f.write(data)
                return True
    except Exception as e:
        print(f"Image gen error: {e}")

    # 3. Last Resort Fallback - Placeholder Image (Prevents Black Screen)
    try:
        fallback_url = f'https://placehold.co/1280x720/000000/FFFFFF/png?text={urllib.parse.quote(prompt[:50])}'
        img_path = out_path.replace('.mp4', '.jpg')
        req = urllib.request.Request(fallback_url, headers={'User-Agent': 'Inkwell/3.0'})
        with urllib.request.urlopen(req, timeout=30) as resp:
            with open(img_path, 'wb') as f:
                f.write(resp.read())
        return True
    except:
        return False


# ─────────────────────────────────────────────────────────────────────────────
# Audio Generation (Edge-TTS + gTTS Fallback)
# ─────────────────────────────────────────────────────────────────────────────
def _generate_audio(text: str, out_path: str) -> bool:
    """
    Generates high-quality speech.
    Uses Edge-TTS (Neural) as primary and gTTS as fallback.
    """
    # 1. Try Edge-TTS (Neural Quality) via Python API
    try:
        import asyncio
        import edge_tts

        async def _save_edge_audio():
            # Use a professional, warm voice
            communicate = edge_tts.Communicate(text[:1000], "en-US-GuyNeural")
            await communicate.save(out_path)

        try:
            # Try to get existing loop or create new one for the thread
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            loop.run_until_complete(_save_edge_audio())
            loop.close()
        except Exception as e:
            print(f"Edge-TTS Async Loop failed: {e}")
            # Fallback to CLI if library fails
            import subprocess
            cmd = ['edge-tts', '--text', text[:1000], '--write-media', out_path, '--voice', 'en-US-GuyNeural']
            subprocess.run(cmd, check=True, capture_output=True)

        if os.path.exists(out_path) and os.path.getsize(out_path) > 500:
            return True
    except Exception as e:
        print(f"Edge-TTS total failure: {e}")

    # 2. Fallback to gTTS (Google Translate)
    try:
        from gtts import gTTS
        tts = gTTS(text=text[:500], lang='en', slow=False)
        tts.save(out_path)
        return os.path.exists(out_path) and os.path.getsize(out_path) > 500
    except Exception as e:
        print(f"gTTS failed: {e}")
        return False


# ─────────────────────────────────────────────────────────────────────────────
# SRT subtitle helpers
# ─────────────────────────────────────────────────────────────────────────────
def _seconds_to_srt_time(s: float) -> str:
    h = int(s // 3600)
    m = int((s % 3600) // 60)
    sec = int(s % 60)
    ms = int((s - int(s)) * 1000)
    return f'{h:02d}:{m:02d}:{sec:02d},{ms:03d}'

def _build_srt(scenes: list) -> str:
    lines = []
    t = 0.0
    for i, sc in enumerate(scenes, 1):
        end = t + sc.duration_seconds
        lines.append(str(i))
        lines.append(f'{_seconds_to_srt_time(t)} --> {_seconds_to_srt_time(end)}')
        # Wrap long narration text
        wrapped = '\n'.join(textwrap.wrap(sc.narration_text, width=60))
        lines.append(wrapped)
        lines.append('')
        t = end
    return '\n'.join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# FFmpeg Video Rendering
# ─────────────────────────────────────────────────────────────────────────────
def _ffmpeg(*args, check=True):
    cmd = ['ffmpeg', '-y', '-loglevel', 'error'] + list(args)
    result = subprocess.run(cmd, capture_output=True, text=True)
    if check and result.returncode != 0:
        raise RuntimeError(f'FFmpeg error: {result.stderr[:500]}')
    return result


def process_scene_parallel(sc_data, workdir, job_id, flask_app):
    """Processes a single scene: asset download, audio gen, and clip render."""
    with flask_app.app_context():
        sc_id = sc_data['id']
        sc_num = sc_data['scene_number']

        # ── Visual Asset ───────────────────────────────────────────
        visual_path = os.path.join(workdir, f'asset_{sc_num:03d}.mp4')
        prompt = f"{sc_data['image_prompt']}. {sc_data['character_details']}. {sc_data['environment_details']}"
        _download_visual(prompt, visual_path)

        img_fallback = visual_path.replace('.mp4', '.jpg')
        has_image = os.path.exists(img_fallback)
        has_video = os.path.exists(visual_path) and os.path.getsize(visual_path) > 5000

        # ── Audio ──────────────────────────────────────────────────
        mp3_path = os.path.join(workdir, f'audio_{sc_num:03d}.mp3')
        has_audio = _generate_audio(sc_data['narration_text'], mp3_path)
        if not has_audio:
            _ffmpeg('-f', 'lavfi', '-i', 'anullsrc=r=44100:cl=mono', '-t', '5', mp3_path)

        # Get duration
        try:
            probe = subprocess.run(
                ['ffprobe', '-v', 'error', '-show_entries', 'format=duration',
                 '-of', 'default=noprint_wrappers=1:nokey=1', mp3_path],
                capture_output=True, text=True)
            actual_dur = max(float(probe.stdout.strip() or 5.0), 2.0)
        except:
            actual_dur = 5.0

        # ── FFmpeg Render Clip ─────────────────────────────────────
        clip_path = os.path.join(workdir, f'clip_{sc_num:03d}.mp4')

        # TURBO PRESET
        if has_video:
            # Explicitly map video from input 0 and audio from input 1 (the generated narration)
            # This prevents FFmpeg from picking the silent audio track often present in AI-generated videos
            _ffmpeg(
                '-stream_loop', '-1', '-i', visual_path, '-i', mp3_path,
                '-map', '0:v:0', '-map', '1:a:0',
                '-t', str(actual_dur),
                '-vf', "scale=1280:720:force_original_aspect_ratio=increase,crop=1280:720",
                '-c:v', 'libx264', '-preset', 'ultrafast', '-tune', 'zerolatency', '-pix_fmt', 'yuv420p',
                '-c:a', 'aac', '-b:a', '128k', '-shortest', clip_path
            )
        elif has_image:
            _ffmpeg(
                '-loop', '1', '-i', img_fallback, '-i', mp3_path,
                '-t', str(actual_dur),
                '-vf', "scale=1280:720:force_original_aspect_ratio=increase,crop=1280:720,format=yuv420p",
                '-c:v', 'libx264', '-preset', 'ultrafast', '-tune', 'stillimage',
                '-c:a', 'aac', '-b:a', '128k', '-shortest', clip_path
            )
        else:
            _ffmpeg(
                '-f', 'lavfi', '-i', 'color=c=blue:s=1280x720:r=25', '-i', mp3_path,
                '-t', str(actual_dur),
                '-c:v', 'libx264', '-preset', 'ultrafast', '-pix_fmt', 'yuv420p',
                '-c:a', 'aac', '-b:a', '128k', '-shortest', clip_path
            )

        # Update scene in DB
        from extensions import db
        sc_db = VideoScene.query.get(sc_id)
        if sc_db:
            sc_db.status = 'done'
            sc_db.image_path = img_fallback if has_image else ''
            db.session.commit()
        return clip_path

def render_video(job_id: int, flask_app):
    """
    ULTRA-SPEED Rendering Pipeline:
    Uses parallel processing for assets and clips.
    """
    with flask_app.app_context():
        job = VideoJob.query.get(job_id)

        job.status = 'processing'
        db.session.commit()

        workdir = tempfile.mkdtemp(prefix=f'inkwell_video_{job_id}_')
        scenes = VideoScene.query.filter_by(job_id=job_id).order_by(VideoScene.scene_number).all()
        job.total_scenes = len(scenes)
        db.session.commit()

        # Extract serializable data for threads
        scenes_data = [{
            'id': s.id,
            'scene_number': s.scene_number,
            'image_prompt': s.image_prompt,
            'character_details': s.character_details,
            'environment_details': s.environment_details,
            'narration_text': s.narration_text
        } for s in scenes]

        clip_paths = []
        try:
            # Reduced workers to 2 for SQLite stability
            max_workers = 2
            with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = [executor.submit(process_scene_parallel, sc, workdir, job_id, flask_app) for sc in scenes_data]

                for future in concurrent.futures.as_completed(futures):
                    future.result()
                    # Increment job progress in main thread context
                    job.done_scenes += 1
                    db.session.commit()

            # Ensure clip_paths are in correct order
            clip_paths = [os.path.join(workdir, f'clip_{sc.scene_number:03d}.mp4') for sc in scenes]
            clip_paths = [cp for cp in clip_paths if os.path.exists(cp)]

            if not clip_paths:
                raise RuntimeError("No clips generated")

            # Merge all
            concat_file = os.path.join(workdir, 'concat.txt')
            with open(concat_file, 'w') as f:
                for cp in clip_paths:
                    f.write(f"file '{cp}'\n")

            merged_path = os.path.join(workdir, 'merged.mp4')
            _ffmpeg('-f', 'concat', '-safe', '0', '-i', concat_file, '-c', 'copy', merged_path)

            # Subtitles
            srt_path = os.path.join(workdir, 'subs.srt')
            with open(srt_path, 'w', encoding='utf-8') as f:
                f.write(_build_srt(scenes))

            # Final Burn-in
            static_videos_dir = os.path.join(current_app.root_path, 'static', 'videos')
            os.makedirs(static_videos_dir, exist_ok=True)
            final_path = os.path.join(static_videos_dir, f'job_{job_id}.mp4')

            # Save thumbnail from first scene
            first_scene = scenes[0] if scenes else None
            thumb_path = ''
            if first_scene:
                src_thumb = os.path.join(workdir, f'asset_{first_scene.scene_number:03d}.jpg')
                if os.path.exists(src_thumb):
                    thumb_static_path = os.path.join(static_videos_dir, f'thumb_{job_id}.jpg')
                    import shutil
                    shutil.copy2(src_thumb, thumb_static_path)
                    thumb_path = f'static/videos/thumb_{job_id}.jpg'

            srt_escaped = srt_path.replace('\\', '/').replace(':', '\\:')
            try:
                _ffmpeg(
                    '-i', merged_path,
                    '-vf', f"subtitles='{srt_escaped}':force_style='FontSize=20,PrimaryColour=&Hffffff&,OutlineColour=&H000000&,BorderStyle=3,Outline=1,Shadow=1,MarginV=30'",
                    '-c:v', 'libx264', '-crf', '23', '-preset', 'ultrafast', '-c:a', 'copy',
                    final_path
                )
            except Exception as e:
                print(f"Subtitle burn-in failed, using merged video without subs: {e}")
                import shutil
                shutil.copy2(merged_path, final_path)

            size_mb = round(os.path.getsize(final_path) / (1024*1024), 2)
            output = VideoOutput(job_id=job_id, file_path=f'static/videos/job_{job_id}.mp4', file_size_mb=size_mb)
            db.session.add(output)

            # Update first scene with relative thumbnail path
            if first_scene and thumb_path:
                first_scene.image_path = thumb_path

            job.status = 'done'
            db.session.commit()

            # Cleanup temp workdir
            try:
                import shutil
                shutil.rmtree(workdir)
            except:
                pass

        except Exception as e:
            import traceback
            traceback.print_exc()
            job.status = 'failed'
            db.session.add(VideoFailedJob(job_id=job_id, error_message=str(e)))
            db.session.commit()


# ─────────────────────────────────────────────────────────────────────────────
# Routes
# ─────────────────────────────────────────────────────────────────────────────

@video_bp.route('/generate/<int:post_id>', methods=['POST'])
@login_required
def generate(post_id):
    from models import Post
    post = Post.query.get_or_404(post_id)
    if post.user_id != current_user.id:
        abort(403)
    if post.status != 'published':
        flash('Only published stories can be converted to video.', 'warning')
        return redirect(url_for('post_detail', slug=post.slug))

    # Check for in-progress job
    existing = VideoJob.query.filter_by(post_id=post_id, user_id=current_user.id).filter(
        VideoJob.status.in_(['queued', 'processing'])
    ).first()
    if existing:
        flash('A video is already being generated for this story.', 'info')
        return redirect(url_for('video.studio'))

    # Create job
    job = VideoJob(post_id=post_id, user_id=current_user.id, status='queued')
    db.session.add(job)
    db.session.commit()

    # Generate scenes (quick — just calls Groq API)
    try:
        generate_scenes(post.body, post.title, job.id)
    except Exception as e:
        job.status = 'failed'
        db.session.add(VideoFailedJob(job_id=job.id, error_message=str(e)[:500]))
        db.session.commit()
        flash(f'Scene generation failed: {e}', 'danger')
        return redirect(url_for('video.studio'))

    # Start rendering in background
    flask_app = current_app._get_current_object()
    t = threading.Thread(target=render_video, args=(job.id, flask_app), daemon=True)
    t.start()

    flash('🎬 Video generation started! Check Video Studio for progress.', 'success')
    return redirect(url_for('video.studio'))


@video_bp.route('/status/<int:job_id>')
@login_required
def status(job_id):
    job = VideoJob.query.get_or_404(job_id)
    if job.user_id != current_user.id:
        abort(403)
    download_url = None
    if job.status == 'done' and job.output:
        download_url = url_for('video.download', job_id=job.id)
    return jsonify({
        'status':           job.status,
        'progress_percent': job.progress_percent,
        'total_scenes':     job.total_scenes,
        'done_scenes':      job.done_scenes,
        'download_url':     download_url,
    })


@video_bp.route('/studio')
@login_required
def studio():
    jobs = (VideoJob.query
            .filter_by(user_id=current_user.id)
            .order_by(VideoJob.created_at.desc())
            .all())
    groq_key_set = bool(os.environ.get('GROQ_API_KEY', '').strip())
    return render_template('video_studio.html', jobs=jobs, groq_key_set=groq_key_set)


@video_bp.route('/retry/<int:job_id>', methods=['POST'])
@login_required
def retry_job(job_id):
    job = VideoJob.query.get_or_404(job_id)
    if job.user_id != current_user.id:
        abort(403)
    if job.status != 'failed':
        flash('Only failed jobs can be retried.', 'warning')
        return redirect(url_for('video.studio'))

    job.status = 'queued'
    job.done_scenes = 0

    # Clear old failures
    VideoFailedJob.query.filter_by(job_id=job_id).delete()

    # Reset scene status to force re-download/re-render
    for scene in job.scenes:
        scene.status = 'pending'
        scene.image_path = ''
        scene.audio_path = ''

    # Regenerate scenes if missing
    if not job.scenes:
        try:
            generate_scenes(job.post.body, job.post.title, job.id)
        except Exception as e:
            job.status = 'failed'
            db.session.add(VideoFailedJob(job_id=job.id, error_message=f"Regen scenes failed: {e}"))
            db.session.commit()
            flash(f'Scene regeneration failed: {e}', 'danger')
            return redirect(url_for('video.studio'))

    db.session.commit()

    flask_app = current_app._get_current_object()
    t = threading.Thread(target=render_video, args=(job.id, flask_app), daemon=True)
    t.start()

    flash('Video generation retried!', 'success')
    return redirect(url_for('video.studio'))


@video_bp.route('/thumbnail/<int:job_id>')
def thumbnail(job_id):
    job = VideoJob.query.get_or_404(job_id)
    # Return first scene image as thumbnail
    scene = VideoScene.query.filter_by(job_id=job.id).order_by(VideoScene.scene_number).first()
    if scene and scene.image_path:
        full_thumb_path = os.path.join(current_app.root_path, scene.image_path)
        if os.path.exists(full_thumb_path):
            return send_file(full_thumb_path, mimetype='image/jpeg')
    return redirect('https://placehold.co/600x400?text=No+Thumbnail')


@video_bp.route('/publish/<int:job_id>', methods=['POST'])
@login_required
def publish_video(job_id):
    job = VideoJob.query.get_or_404(job_id)
    if job.user_id != current_user.id: abort(403)
    # In a real app, this might set a 'is_public' flag
    flash('Video published to your profile!', 'success')
    return redirect(url_for('video.studio'))


@video_bp.route('/scene/<int:scene_id>/regenerate', methods=['POST'])
@login_required
def regenerate_scene(scene_id):
    scene = VideoScene.query.get_or_404(scene_id)
    if scene.job.user_id != current_user.id: abort(403)

    # Simple regeneration: just delete the asset so it can be re-downloaded if we had a per-scene render
    # But currently render_video does everything in one go.
    # To support this properly, we'd need to change how assets are stored.
    # For now, let's just allow editing the prompt.
    new_prompt = request.form.get('image_prompt')
    if new_prompt:
        scene.image_prompt = new_prompt
        db.session.commit()
        flash('Scene prompt updated. You may need to restart the video generation.', 'success')
    return redirect(url_for('video.studio'))


@video_bp.route('/analytics')
@login_required
def analytics():
    jobs = VideoJob.query.filter_by(user_id=current_user.id).all()
    total_views = sum(job.output.view_count for job in jobs if job.output)
    total_videos = len([j for j in jobs if j.status == 'done'])
    return render_template('video_analytics.html', total_views=total_views, total_videos=total_videos, jobs=jobs)


@video_bp.route('/download/<int:job_id>')
@login_required
def download(job_id):
    job = VideoJob.query.get_or_404(job_id)
    if job.user_id != current_user.id:
        abort(403)
    if not job.output:
        abort(404)
    # Ensure full path
    full_path = os.path.join(current_app.root_path, job.output.file_path)
    if not os.path.exists(full_path):
        abort(404)

    # Track download as a view
    job.output.view_count += 1
    db.session.commit()

    return send_file(
        full_path,
        as_attachment=True,
        download_name=f'inkwell_video_{job_id}.mp4',
        mimetype='video/mp4',
    )


@video_bp.route('/export-youtube/<int:job_id>', methods=['POST'])
@login_required
def export_youtube(job_id):
    flash('YouTube export started! (Simulation)', 'info')
    return redirect(url_for('video.studio'))


@video_bp.route('/delete/<int:job_id>', methods=['POST'])
@login_required
def delete_job(job_id):
    job = VideoJob.query.get_or_404(job_id)
    if job.user_id != current_user.id:
        abort(403)
    # Delete video file if exists
    if job.output and job.output.file_path and os.path.exists(job.output.file_path):
        try:
            os.remove(job.output.file_path)
        except OSError:
            pass
    db.session.delete(job)
    db.session.commit()
    flash('Video job deleted.', 'success')
    return redirect(url_for('video.studio'))
