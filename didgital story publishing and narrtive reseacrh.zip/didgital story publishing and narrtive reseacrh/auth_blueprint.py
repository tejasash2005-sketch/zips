from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required, current_user
from extensions import db, bcrypt
from models import User, LoginHistory
import os

auth_bp = Blueprint('auth', __name__)

def add_notification(user_id, message, type='info', link=''):
    from models import Notification
    db.session.add(Notification(user_id=user_id, message=message, type=type, link=link))
    db.session.commit()

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('posts.index'))
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        confirm = request.form.get('confirm', '')
        if not all([username, email, password, confirm]):
            flash('All fields are required.', 'error')
        elif password != confirm:
            flash('Passwords do not match.', 'error')
        elif len(password) < 6:
            flash('Password must be at least 6 characters.', 'error')
        elif User.query.filter_by(username=username).first():
            flash('Username already taken.', 'error')
        elif User.query.filter_by(email=email).first():
            flash('Email already registered.', 'error')
        else:
            hashed = bcrypt.generate_password_hash(password).decode('utf-8')
            user = User(username=username, email=email, password=hashed)
            db.session.add(user)
            db.session.commit()
            login_user(user)
            add_notification(user.id, f'🎉 Welcome to Inkwell, {username}! Start writing your first story.', type='success')
            flash(f'Welcome to Inkwell, {username}!', 'success')
            return redirect(url_for('posts.index'))
    return render_template('register.html')

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('posts.index'))
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        remember = request.form.get('remember') == 'on'
        ip = request.headers.get('X-Forwarded-For', request.remote_addr or '').split(',')[0].strip()
        ua = request.headers.get('User-Agent', '')[:300]
        user = User.query.filter_by(email=email).first()
        if user and bcrypt.check_password_hash(user.password, password):
            if user.is_banned:
                db.session.add(LoginHistory(user_id=user.id, ip_address=ip, user_agent=ua, status='banned'))
                db.session.commit()
                flash('Your account has been suspended.', 'error')
                return render_template('login.html')
            db.session.add(LoginHistory(user_id=user.id, ip_address=ip, user_agent=ua, status='success'))
            db.session.commit()
            login_user(user, remember=remember)
            flash(f'Welcome back, {user.username}!', 'success')
            return redirect(request.args.get('next') or url_for('posts.index'))
        if user:
            db.session.add(LoginHistory(user_id=user.id, ip_address=ip, user_agent=ua, status='failed'))
            db.session.commit()
        flash('Invalid email or password.', 'error')
    return render_template('login.html')

@auth_bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('posts.index'))

@auth_bp.route('/profile/<username>')
def profile(username):
    from models import Post
    user = User.query.filter_by(username=username).first_or_404()
    published = Post.query.filter_by(user_id=user.id, status='published').order_by(Post.created_at.desc()).all()
    pending = rejected = []
    if current_user.is_authenticated and current_user.id == user.id:
        pending = Post.query.filter_by(user_id=user.id, status='pending').order_by(Post.created_at.desc()).all()
        rejected = Post.query.filter_by(user_id=user.id, status='rejected').order_by(Post.created_at.desc()).all()
    return render_template('profile.html', user=user, published=published, pending=pending, rejected=rejected)

@auth_bp.route('/profile/edit', methods=['GET', 'POST'])
@login_required
def edit_profile():
    if request.method == 'POST':
        current_user.bio = request.form.get('bio', '').strip()
        db.session.commit()
        flash('Profile updated!', 'success')
        return redirect(url_for('auth.profile', username=current_user.username))
    return render_template('edit_profile.html', user=current_user)

@auth_bp.route('/login-history')
@login_required
def login_history():
    history = LoginHistory.query.filter_by(user_id=current_user.id).order_by(LoginHistory.created_at.desc()).limit(50).all()
    return render_template('login_history.html', history=history)


@auth_bp.route('/notifications')
@login_required
def notifications():
    from models import Notification
    notifs = Notification.query.filter_by(user_id=current_user.id).order_by(Notification.created_at.desc()).limit(50).all()
    for n in notifs:
        n.is_read = True
    db.session.commit()
    return render_template('notifications.html', notifications=notifs)

@auth_bp.route('/bookmarks')
@login_required
def bookmarks():
    from models import Bookmark
    bms = Bookmark.query.filter_by(user_id=current_user.id).order_by(Bookmark.created_at.desc()).all()
    return render_template('bookmarks.html', bookmarks=bms)

@auth_bp.route('/my-stats')
@login_required
def my_stats():
    from models import Post, Comment, Like
    posts = Post.query.filter_by(user_id=current_user.id, status='published').all()
    total_views = sum(p.view_count or 0 for p in posts)
    total_likes = sum(p.like_count for p in posts)
    total_comments = sum(p.comment_count for p in posts)
    return render_template('my_stats.html', posts=posts, total_views=total_views,
                           total_likes=total_likes, total_comments=total_comments)
