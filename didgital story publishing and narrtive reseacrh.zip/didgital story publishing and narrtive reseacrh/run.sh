#!/bin/bash
# ── Inkwell v3 — run script ──────────────────────────────────────────────────
# Set your Groq API key before running (free at https://console.groq.com):
#   export GROQ_API_KEY=gsk_...
# FFmpeg must be installed: https://ffmpeg.org/download.html

echo "=================================="
echo "  Inkwell v3 — Story Platform"
echo "  AI powered by Groq (Free)"
echo "=================================="
echo ""
echo "Installing dependencies..."
pip install -r requirements.txt -q
echo ""
echo "Starting server..."
echo "Open: http://127.0.0.1:5000"
echo ""
python app.py
