"""
api_blueprint.py – RESTful JSON API for Inkwell
Endpoints:
  GET  /api/posts            paginated published posts
  GET  /api/post/<id>        single post + comments
  POST /api/register         register → JWT token
  POST /api/login            login    → JWT token
  POST /api/post             create post (JWT required)
  GET  /api/user/<username>  public user profile
"""
from flask import Blueprint, jsonify, request
from flask_jwt_extended import (
    create_access_token, jwt_required, get_jwt_identity
)
from extensions import db, bcrypt
from models import User, Post, Comment, make_slug
from datetime import datetime, timezone

api_bp = Blueprint('api', __name__, url_prefix='/api')

# ── Helpers ───────────────────────────────────────────────────────────────────

def _post_dict(p):
    return {
        'id': p.id,
        'title': p.title,
        'slug': p.slug,
        'excerpt': p.excerpt,
        'category': p.category,
        'tags': p.tags,
        'author': p.author.username,
        'view_count': p.view_count or 0,
        'like_count': p.like_count,
        'comment_count': p.comment_count,
        'created_at': p.created_at.isoformat() if p.created_at else None,
    }

def _comment_dict(c):
    return {
        'id': c.id,
        'body': c.body,
        'author': c.author.username,
        'created_at': c.created_at.isoformat() if c.created_at else None,
    }

def _user_dict(u):
    return {
        'id': u.id,
        'username': u.username,
        'bio': u.bio or '',
        'post_count': u.post_count,
        'joined_at': u.joined_at.isoformat() if u.joined_at else None,
    }

# ── GET /api/posts ─────────────────────────────────────────────────────────────
@api_bp.route('/posts', methods=['GET'])
def api_posts():
    page  = request.args.get('page',  1,  type=int)
    limit = request.args.get('limit', 10, type=int)
    limit = min(limit, 50)   # hard cap

    q = request.args.get('q', '').strip()
    category = request.args.get('category', '').strip()

    query = Post.query.filter_by(status='published').order_by(Post.created_at.desc())
    if q:
        query = query.filter(
            db.or_(Post.title.ilike(f'%{q}%'), Post.body.ilike(f'%{q}%'), Post.tags.ilike(f'%{q}%'))
        )
    if category:
        query = query.filter_by(category=category)

    pagination = query.paginate(page=page, per_page=limit, error_out=False)
    return jsonify({
        'posts': [_post_dict(p) for p in pagination.items],
        'total': pagination.total,
        'pages': pagination.pages,
        'page':  page,
        'limit': limit,
    }), 200

# ── GET /api/post/<id> ─────────────────────────────────────────────────────────
@api_bp.route('/post/<int:post_id>', methods=['GET'])
def api_post_detail(post_id):
    post = Post.query.filter_by(id=post_id, status='published').first()
    if not post:
        return jsonify({'error': 'Post not found'}), 404
    data = _post_dict(post)
    data['body'] = post.body
    data['comments'] = [_comment_dict(c) for c in post.comments]
    return jsonify(data), 200

# ── POST /api/register ─────────────────────────────────────────────────────────
@api_bp.route('/register', methods=['POST'])
def api_register():
    data = request.get_json(silent=True) or {}
    username = data.get('username', '').strip()
    email    = data.get('email', '').strip().lower()
    password = data.get('password', '')

    if not all([username, email, password]):
        return jsonify({'error': 'username, email, and password are required'}), 400
    if len(password) < 6:
        return jsonify({'error': 'Password must be at least 6 characters'}), 400
    if User.query.filter_by(username=username).first():
        return jsonify({'error': 'Username already taken'}), 409
    if User.query.filter_by(email=email).first():
        return jsonify({'error': 'Email already registered'}), 409

    hashed = bcrypt.generate_password_hash(password).decode('utf-8')
    user = User(username=username, email=email, password=hashed)
    db.session.add(user)
    db.session.commit()

    token = create_access_token(identity=str(user.id))
    return jsonify({'token': token, 'user': _user_dict(user)}), 201

# ── POST /api/login ────────────────────────────────────────────────────────────
@api_bp.route('/login', methods=['POST'])
def api_login():
    data = request.get_json(silent=True) or {}
    email    = data.get('email', '').strip().lower()
    password = data.get('password', '')

    if not email or not password:
        return jsonify({'error': 'email and password are required'}), 400

    user = User.query.filter_by(email=email).first()
    if not user or not bcrypt.check_password_hash(user.password, password):
        return jsonify({'error': 'Invalid credentials'}), 401
    if user.is_banned:
        return jsonify({'error': 'Account suspended'}), 403

    token = create_access_token(identity=str(user.id))
    return jsonify({'token': token, 'user': _user_dict(user)}), 200

# ── POST /api/post ─────────────────────────────────────────────────────────────
@api_bp.route('/post', methods=['POST'])
@jwt_required()
def api_create_post():
    user_id = int(get_jwt_identity())
    user = db.session.get(User, user_id)
    if not user:
        return jsonify({'error': 'User not found'}), 404

    data = request.get_json(silent=True) or {}
    title    = data.get('title', '').strip()
    body     = data.get('body', '').strip()
    category = data.get('category', 'General').strip()
    tags     = data.get('tags', '').strip()

    if not title or not body:
        return jsonify({'error': 'title and body are required'}), 400
    if len(body.split()) < 20:
        return jsonify({'error': 'Body must be at least 20 words'}), 400

    import bleach
    ALLOWED_TAGS = ['p','br','strong','em','ul','ol','li','h2','h3','blockquote','a','code','pre']
    body  = bleach.clean(body, tags=ALLOWED_TAGS, strip=True)
    title = bleach.clean(title, tags=[], strip=True)

    slug = make_slug(title)
    # ensure slug uniqueness
    base, n = slug, 1
    while Post.query.filter_by(slug=slug).first():
        slug = f"{base}-{n}"; n += 1

    excerpt = body[:200].strip() + ('…' if len(body) > 200 else '')
    post = Post(
        title=title, slug=slug, body=body, excerpt=excerpt,
        category=category, tags=tags, user_id=user.id,
        status='pending',
    )
    db.session.add(post)
    db.session.commit()
    return jsonify({'message': 'Post submitted for review', 'post': _post_dict(post)}), 201

# ── GET /api/user/<username> ───────────────────────────────────────────────────
@api_bp.route('/user/<username>', methods=['GET'])
def api_user(username):
    user = User.query.filter_by(username=username).first()
    if not user:
        return jsonify({'error': 'User not found'}), 404
    data = _user_dict(user)
    data['recent_posts'] = [
        _post_dict(p)
        for p in Post.query.filter_by(user_id=user.id, status='published')
                           .order_by(Post.created_at.desc()).limit(5).all()
    ]
    return jsonify(data), 200
