"""tests/test_admin.py — Admin routes + REST API tests"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from conftest import register_user, login_user_http, logout_user


def _admin_login(client):
    login_user_http(client, 'admin@inkwell.com', 'admin123')


class TestAdminAccess:
    def test_admin_dashboard_as_guest_redirects(self, client):
        logout_user(client)
        r = client.get('/admin/', follow_redirects=False)
        assert r.status_code in (302, 403)

    def test_admin_dashboard_as_admin(self, client):
        _admin_login(client)
        r = client.get('/admin/')
        assert r.status_code == 200

    def test_admin_review_page(self, client):
        _admin_login(client)
        r = client.get('/admin/review')
        assert r.status_code == 200

    def test_admin_users_page(self, client):
        _admin_login(client)
        r = client.get('/admin/users')
        assert r.status_code == 200

    def test_admin_analytics_page(self, client):
        _admin_login(client)
        r = client.get('/admin/analytics')
        assert r.status_code == 200

    def test_admin_audit_log_page(self, client):
        _admin_login(client)
        r = client.get('/admin/audit-log')
        assert r.status_code == 200


class TestAdminPostActions:
    def _pending_id(self, app):
        from models import Post
        with app.app_context():
            p = Post.query.filter_by(status='pending').first()
            return p.id if p else None

    def test_approve_post(self, client, app):
        _admin_login(client)
        pid = self._pending_id(app)
        if not pid:
            import pytest; pytest.skip('No pending post')
        r = client.post(f'/admin/review/{pid}/approve', follow_redirects=False)
        assert r.status_code in (200, 302)

    def test_reject_post(self, client, app):
        _admin_login(client)
        from models import Post, User
        from extensions import db
        with app.app_context():
            u = User.query.filter_by(is_admin=False).first()
            from models import make_slug
            p = Post(title='Reject Test', slug=make_slug('Reject Test'),
                     body='Body text here', excerpt='Body', category='General',
                     user_id=u.id, status='pending')
            db.session.add(p); db.session.commit()
            pid = p.id
        r = client.post(f'/admin/review/{pid}/reject',
                        data={'reason': 'Test rejection'}, follow_redirects=False)
        assert r.status_code in (200, 302)


class TestRestAPI:
    def test_api_posts_list(self, client):
        r = client.get('/api/posts')
        assert r.status_code == 200
        assert 'posts' in r.get_json()

    def test_api_posts_pagination(self, client):
        r = client.get('/api/posts?page=1&limit=5')
        assert r.status_code == 200
        assert r.get_json()['limit'] == 5

    def test_api_register(self, client):
        r = client.post('/api/register', json={
            'username': 'apitest1', 'email': 'api1@test.com', 'password': 'apipass123'})
        assert r.status_code == 201
        assert 'token' in r.get_json()

    def test_api_register_duplicate(self, client):
        client.post('/api/register', json={
            'username': 'apidup', 'email': 'apidup@test.com', 'password': 'pass123'})
        r = client.post('/api/register', json={
            'username': 'apidup', 'email': 'apidup@test.com', 'password': 'pass123'})
        assert r.status_code == 409

    def test_api_login_success(self, client):
        client.post('/api/register', json={
            'username': 'apilogin', 'email': 'apilogin@test.com', 'password': 'loginpass'})
        r = client.post('/api/login', json={
            'email': 'apilogin@test.com', 'password': 'loginpass'})
        assert r.status_code == 200
        assert 'token' in r.get_json()

    def test_api_login_wrong_creds(self, client):
        r = client.post('/api/login', json={
            'email': 'nobody@test.com', 'password': 'wrong'})
        assert r.status_code == 401

    def test_api_user_profile(self, client):
        r = client.get('/api/user/admin')
        assert r.status_code == 200
        assert r.get_json()['username'] == 'admin'

    def test_api_user_not_found(self, client):
        r = client.get('/api/user/doesnotexist99')
        assert r.status_code == 404

    def test_api_create_post_no_token(self, client):
        r = client.post('/api/post', json={'title': 'X', 'body': 'Y'})
        assert r.status_code == 401

    def test_api_create_post_with_token(self, client):
        reg = client.post('/api/register', json={
            'username': 'jwtposter', 'email': 'jwtposter@test.com', 'password': 'jwtpass'})
        token = reg.get_json()['token']
        r = client.post('/api/post',
            json={'title': 'JWT Post Test',
                  'body': ('This post is created via the REST API using a JWT token. '
                           'It has enough words to pass the quality gate. Flask-JWT-Extended '
                           'makes token auth easy and secure for production REST APIs.'),
                  'category': 'Technology', 'tags': 'api,jwt'},
            headers={'Authorization': f'Bearer {token}'})
        assert r.status_code == 201
        assert r.get_json()['post']['title'] == 'JWT Post Test'
