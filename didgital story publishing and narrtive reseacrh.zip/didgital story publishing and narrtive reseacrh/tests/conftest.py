"""
tests/conftest.py  –  Shared pytest fixtures for Inkwell
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import pytest


@pytest.fixture(scope='session')
def app():
    from app import create_app
    test_app = create_app({
        'TESTING': True,
        'SQLALCHEMY_DATABASE_URI': 'sqlite:///:memory:',
        'WTF_CSRF_ENABLED': False,
        'SECRET_KEY': 'test-secret',
        'JWT_SECRET_KEY': 'test-jwt-secret',
        'RATELIMIT_ENABLED': False,
    })
    yield test_app


@pytest.fixture(scope='session')
def client(app):
    return app.test_client()


# ── Helpers ───────────────────────────────────────────────────────────────────

def register_user(client, username, email, password):
    return client.post('/register', data={
        'username': username, 'email': email,
        'password': password, 'confirm': password,
    }, follow_redirects=False)


def login_user_http(client, email, password):
    return client.post('/login', data={
        'email': email, 'password': password,
    }, follow_redirects=False)


def logout_user(client):
    return client.get('/logout', follow_redirects=False)
