"""tests/test_posts.py — Post CRUD, comment, bookmark, like, search tests"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from conftest import register_user, login_user_http, logout_user

BODY = ('Deep work is the ability to focus without distraction on a cognitively '
        'demanding task. It allows you to produce better results in less time. '
        'Professionals who can perform deep work are increasingly rare yet '
        'increasingly valuable in our distracted economy. Schedule uninterrupted '
        'blocks every day and commit fully to one task.')


def _auth_client(client):
    """Register+login a fresh test author, return slug of created published post."""
    register_user(client, 'pauthor', 'pauthor@test.com', 'pass1234')
    login_user_http(client, 'pauthor@test.com', 'pass1234')


class TestIndex:
    def test_homepage_loads(self, client):
        r = client.get('/')
        assert r.status_code == 200

    def test_pagination_param(self, client):
        r = client.get('/?page=1')
        assert r.status_code == 200

    def test_search_returns_200(self, client):
        r = client.get('/?q=deep+work')
        assert r.status_code == 200

    def test_search_no_results(self, client):
        r = client.get('/?q=xyznonexistent999')
        assert r.status_code == 200

    def test_category_filter(self, client):
        r = client.get('/?category=Technology')
        assert r.status_code == 200


class TestCreatePost:
    def test_new_post_page_requires_login(self, client):
        logout_user(client)
        r = client.get('/post/new', follow_redirects=False)
        assert r.status_code in (302, 401)

    def test_new_post_page_loads_when_authed(self, client):
        register_user(client, 'postwr1', 'postwr1@test.com', 'pass1234')
        login_user_http(client, 'postwr1@test.com', 'pass1234')
        r = client.get('/post/new')
        assert r.status_code == 200

    def test_create_post_success(self, client):
        register_user(client, 'postwr2', 'postwr2@test.com', 'pass1234')
        login_user_http(client, 'postwr2@test.com', 'pass1234')
        r = client.post('/post/new', data={
            'title': 'My Test Post Title',
            'body': BODY,
            'category': 'Technology',
            'tags': 'test,flask',
        }, follow_redirects=False)
        assert r.status_code in (200, 302)

    def test_create_post_missing_title(self, client):
        register_user(client, 'postwr3', 'postwr3@test.com', 'pass1234')
        login_user_http(client, 'postwr3@test.com', 'pass1234')
        r = client.post('/post/new', data={
            'title': '', 'body': BODY,
        }, follow_redirects=False)
        assert r.status_code == 200  # stays on form


class TestCommentBookmarkLike:
    def _get_published_slug(self, app):
        from models import Post
        with app.app_context():
            p = Post.query.filter_by(status='published').first()
            return p.slug if p else None

    def test_comment_on_post(self, client, app):
        slug = self._get_published_slug(app)
        if not slug:
            import pytest; pytest.skip('No published post')
        register_user(client, 'commenter', 'commenter@test.com', 'pass1234')
        login_user_http(client, 'commenter@test.com', 'pass1234')
        r = client.post(f'/post/{slug}/comment',
                        data={'body': 'Great post!'}, follow_redirects=False)
        assert r.status_code in (200, 302)

    def test_bookmark_post(self, client, app):
        slug = self._get_published_slug(app)
        if not slug:
            import pytest; pytest.skip('No published post')
        register_user(client, 'bookmarker', 'bookmarker@test.com', 'pass1234')
        login_user_http(client, 'bookmarker@test.com', 'pass1234')
        r = client.post(f'/post/{slug}/bookmark', follow_redirects=False)
        assert r.status_code in (200, 302)

    def test_like_post(self, client, app):
        slug = self._get_published_slug(app)
        if not slug:
            import pytest; pytest.skip('No published post')
        register_user(client, 'liker', 'liker@test.com', 'pass1234')
        login_user_http(client, 'liker@test.com', 'pass1234')
        r = client.post(f'/post/{slug}/like', follow_redirects=False)
        assert r.status_code in (200, 302)
