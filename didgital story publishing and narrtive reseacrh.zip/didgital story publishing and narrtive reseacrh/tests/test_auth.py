"""tests/test_auth.py — Authentication tests"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from conftest import register_user, login_user_http, logout_user


class TestRegister:
    def test_register_page_loads(self, client):
        logout_user(client)  # ensure not logged in
        r = client.get('/register', follow_redirects=True)
        assert r.status_code == 200
        # Page renders register form
        assert b'Account' in r.data or b'email' in r.data.lower()

    def test_register_success_redirects(self, client):
        logout_user(client)
        r = register_user(client, 'newuser1', 'newuser1@test.com', 'pass1234')
        assert r.status_code in (200, 302)

    def test_register_duplicate_username(self, client):
        logout_user(client)
        register_user(client, 'dupuser', 'dup1@test.com', 'pass1234')
        logout_user(client)
        r = client.post('/register', data={
            'username': 'dupuser', 'email': 'dup2@test.com',
            'password': 'pass1234', 'confirm': 'pass1234',
        }, follow_redirects=True)
        assert b'taken' in r.data or b'already' in r.data.lower()

    def test_register_duplicate_email(self, client):
        logout_user(client)
        register_user(client, 'em1', 'shared@test.com', 'pass1234')
        logout_user(client)
        r = client.post('/register', data={
            'username': 'em2', 'email': 'shared@test.com',
            'password': 'pass1234', 'confirm': 'pass1234',
        }, follow_redirects=True)
        assert b'already' in r.data.lower() or b'registered' in r.data.lower()

    def test_register_password_mismatch(self, client):
        logout_user(client)
        r = client.post('/register', data={
            'username': 'mismatch', 'email': 'mismatch@test.com',
            'password': 'abc123', 'confirm': 'xyz999',
        }, follow_redirects=True)
        assert b'match' in r.data.lower()

    def test_register_short_password(self, client):
        logout_user(client)
        r = client.post('/register', data={
            'username': 'shortpw', 'email': 'short@test.com',
            'password': 'ab', 'confirm': 'ab',
        }, follow_redirects=True)
        assert b'6' in r.data or b'least' in r.data.lower()


class TestLogin:
    def test_login_page_loads(self, client):
        logout_user(client)
        r = client.get('/login', follow_redirects=True)
        assert r.status_code == 200
        assert b'Sign in' in r.data or b'login' in r.data.lower() or b'email' in r.data.lower()

    def test_login_success(self, client):
        logout_user(client)
        register_user(client, 'loginok', 'loginok@test.com', 'goodpass')
        logout_user(client)
        r = login_user_http(client, 'loginok@test.com', 'goodpass')
        assert r.status_code in (200, 302)

    def test_login_wrong_password(self, client):
        logout_user(client)
        register_user(client, 'badpw', 'badpw@test.com', 'correct')
        logout_user(client)
        r = client.post('/login', data={
            'email': 'badpw@test.com', 'password': 'WRONG',
        }, follow_redirects=True)
        assert b'Invalid' in r.data or b'incorrect' in r.data.lower()

    def test_login_unknown_email(self, client):
        logout_user(client)
        r = client.post('/login', data={
            'email': 'nobody@nowhere.com', 'password': 'pass',
        }, follow_redirects=True)
        assert b'Invalid' in r.data or b'incorrect' in r.data.lower()

    def test_logout_redirects(self, client):
        logout_user(client)
        register_user(client, 'logoutme', 'logoutme@test.com', 'pass1234')
        login_user_http(client, 'logoutme@test.com', 'pass1234')
        r = logout_user(client)
        assert r.status_code in (200, 302)
