// ============================================================
// INDUSTRIAL PREDICTIVE MAINTENANCE AI - CORE ENGINE
// Production-Grade Sensor Simulation & AI Analytics
// ============================================================

const APP = {
  currentPage: '',
  role: '',
  updateIntervals: [],
  chartInstances: {},
  sensorData: {},
  alertQueue: [],
};

// ============================================================
// REAL-TIME SENSOR DATA SIMULATION ENGINE
// ============================================================
const SENSORS = {
  machines: [
    { id: 'M-001', name: 'CNC Mill #1', type: 'CNC Milling', plant: 'Plant A', health: 94, status: 'good' },
    { id: 'M-002', name: 'Pump Station A', type: 'Centrifugal Pump', plant: 'Plant A', health: 67, status: 'warning' },
    { id: 'M-003', name: 'Compressor Unit 3', type: 'Air Compressor', plant: 'Plant B', health: 43, status: 'critical' },
    { id: 'M-004', name: 'Conveyor Belt B2', type: 'Conveyor', plant: 'Plant B', health: 88, status: 'good' },
    { id: 'M-005', name: 'Hydraulic Press #5', type: 'Press', plant: 'Plant C', health: 79, status: 'good' },
    { id: 'M-006', name: 'Turbine Gen-1', type: 'Turbine', plant: 'Plant C', health: 55, status: 'warning' },
    { id: 'M-007', name: 'Robot Arm R7', type: 'Industrial Robot', plant: 'Plant A', health: 91, status: 'good' },
    { id: 'M-008', name: 'Heat Exchanger 2', type: 'Heat Exchanger', plant: 'Plant B', health: 72, status: 'warning' },
  ],

  generateReading(base, variance, precision = 1) {
    return parseFloat((base + (Math.random() - 0.5) * variance * 2).toFixed(precision));
  },

  getLiveSensorData(machineId) {
    const m = this.machines.find(x => x.id === machineId) || this.machines[0];
    const stress = m.health < 50 ? 1.4 : m.health < 70 ? 1.15 : 1.0;
    return {
      temperature: this.generateReading(75 * stress, 8, 1),
      vibration: this.generateReading(2.4 * stress, 1.2, 2),
      pressure: this.generateReading(145 * stress, 10, 1),
      rpm: this.generateReading(1450, 30, 0),
      current: this.generateReading(14.5 * stress, 1.5, 2),
      noise: this.generateReading(68 * stress, 5, 1),
      oil_pressure: this.generateReading(55, 6, 1),
      humidity: this.generateReading(42, 8, 1),
      voltage: this.generateReading(415, 5, 1),
      flow_rate: this.generateReading(320, 20, 0),
      torque: this.generateReading(280 * stress, 25, 1),
      efficiency: this.generateReading(88 / stress, 4, 1),
    };
  },

  getHistoricalData(points = 24, base = 75, variance = 12) {
    return Array.from({ length: points }, (_, i) => ({
      t: i,
      v: this.generateReading(base, variance, 1)
    }));
  },

  getPredictions() {
    return [
      { machine: 'Compressor Unit 3', id: 'M-003', type: 'Bearing Failure', probability: 91, eta: '14 hrs', severity: 'critical', confidence: 97, rul: '1.2 days' },
      { machine: 'Pump Station A', id: 'M-002', type: 'Seal Degradation', probability: 73, eta: '3 days', severity: 'warning', confidence: 89, rul: '4.5 days' },
      { machine: 'Turbine Gen-1', id: 'M-006', type: 'Blade Erosion', probability: 58, eta: '7 days', severity: 'caution', confidence: 82, rul: '9 days' },
      { machine: 'Heat Exchanger 2', id: 'M-008', type: 'Fouling Buildup', probability: 44, eta: '12 days', severity: 'caution', confidence: 76, rul: '14 days' },
    ];
  },

  getAlerts() {
    return [
      { id: 1, type: 'critical', machine: 'M-003 Compressor', msg: 'Vibration exceeds threshold by 340% — Imminent bearing failure', time: '2 min ago', ack: false },
      { id: 2, type: 'warning', machine: 'M-002 Pump Station', msg: 'Temperature trending up +12°C over 2h — Monitor closely', time: '18 min ago', ack: false },
      { id: 3, type: 'warning', machine: 'M-006 Turbine', msg: 'Efficiency drop of 8.3% detected — Blade inspection recommended', time: '1 hr ago', ack: true },
      { id: 4, type: 'info', machine: 'M-001 CNC Mill', msg: 'Scheduled PM due in 72 hours — Assign technician', time: '2 hrs ago', ack: true },
      { id: 5, type: 'critical', machine: 'M-003 Compressor', msg: 'Oil pressure critically low — Auto-alert sent to maintenance team', time: '45 min ago', ack: false },
      { id: 6, type: 'info', machine: 'M-007 Robot Arm', msg: 'Calibration drift detected — Self-correction applied', time: '3 hrs ago', ack: true },
    ];
  }
};

// ============================================================
// CHART UTILITIES (Pure Canvas)
// ============================================================
const CHART = {
  colors: {
    cyan: '#00d4ff',
    orange: '#ff6b00',
    green: '#00ff88',
    red: '#ff2d55',
    yellow: '#ffd600',
    purple: '#a855f7',
    muted: '#3d6070',
  },

  drawLine(canvas, data, color = '#00d4ff', fill = true, label = '') {
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const W = canvas.width = canvas.offsetWidth;
    const H = canvas.height = canvas.offsetHeight || 180;
    ctx.clearRect(0, 0, W, H);

    if (!data || data.length < 2) return;

    const vals = data.map(d => typeof d === 'object' ? d.v : d);
    const min = Math.min(...vals) * 0.95;
    const max = Math.max(...vals) * 1.05;
    const range = max - min || 1;

    const xStep = W / (vals.length - 1);
    const yPos = v => H - ((v - min) / range) * (H * 0.8) - H * 0.1;

    // Grid
    ctx.strokeStyle = 'rgba(0,212,255,0.06)';
    ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
      const y = (H / 4) * i;
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
    }

    // Fill
    if (fill) {
      const grad = ctx.createLinearGradient(0, 0, 0, H);
      grad.addColorStop(0, color.replace(')', ',0.25)').replace('rgb', 'rgba').replace('#', 'rgba(') || 'rgba(0,212,255,0.2)');
      grad.addColorStop(1, 'rgba(0,0,0,0)');

      // Parse hex color for gradient
      const r = parseInt(color.slice(1,3),16), g = parseInt(color.slice(3,5),16), b = parseInt(color.slice(5,7),16);
      const fillGrad = ctx.createLinearGradient(0, 0, 0, H);
      fillGrad.addColorStop(0, `rgba(${r},${g},${b},0.2)`);
      fillGrad.addColorStop(1, `rgba(${r},${g},${b},0)`);

      ctx.beginPath();
      ctx.moveTo(0, H);
      vals.forEach((v, i) => ctx.lineTo(i * xStep, yPos(v)));
      ctx.lineTo((vals.length - 1) * xStep, H);
      ctx.closePath();
      ctx.fillStyle = fillGrad;
      ctx.fill();
    }

    // Line
    const r = parseInt(color.slice(1,3),16), g = parseInt(color.slice(3,5),16), b = parseInt(color.slice(5,7),16);
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.shadowColor = `rgba(${r},${g},${b},0.5)`;
    ctx.shadowBlur = 6;
    ctx.lineJoin = 'round';
    ctx.beginPath();
    vals.forEach((v, i) => { i === 0 ? ctx.moveTo(0, yPos(v)) : ctx.lineTo(i * xStep, yPos(v)); });
    ctx.stroke();
    ctx.shadowBlur = 0;
  },

  drawMultiLine(canvas, datasets) {
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const W = canvas.width = canvas.offsetWidth;
    const H = canvas.height = canvas.offsetHeight || 200;
    ctx.clearRect(0, 0, W, H);

    const allVals = datasets.flatMap(d => d.data);
    const min = Math.min(...allVals) * 0.95;
    const max = Math.max(...allVals) * 1.05;
    const range = max - min || 1;

    // Grid
    ctx.strokeStyle = 'rgba(0,212,255,0.06)';
    ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
      const y = (H / 4) * i;
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
    }

    datasets.forEach(({ data, color }) => {
      const xStep = W / (data.length - 1);
      const yPos = v => H - ((v - min) / range) * (H * 0.85) - H * 0.075;
      const r = parseInt(color.slice(1,3),16), g = parseInt(color.slice(3,5),16), b = parseInt(color.slice(5,7),16);

      ctx.strokeStyle = color;
      ctx.lineWidth = 2;
      ctx.shadowColor = `rgba(${r},${g},${b},0.4)`;
      ctx.shadowBlur = 4;
      ctx.lineJoin = 'round';
      ctx.beginPath();
      data.forEach((v, i) => { i === 0 ? ctx.moveTo(0, yPos(v)) : ctx.lineTo(i * xStep, yPos(v)); });
      ctx.stroke();
      ctx.shadowBlur = 0;
    });
  },

  drawBar(canvas, labels, values, colors) {
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const W = canvas.width = canvas.offsetWidth;
    const H = canvas.height = canvas.offsetHeight || 200;
    ctx.clearRect(0, 0, W, H);

    const max = Math.max(...values) * 1.1 || 1;
    const barW = (W / values.length) * 0.65;
    const gap = W / values.length;

    values.forEach((v, i) => {
      const x = i * gap + gap * 0.175;
      const barH = (v / max) * (H - 40);
      const y = H - barH - 20;
      const color = Array.isArray(colors) ? colors[i % colors.length] : colors;

      const r = parseInt(color.slice(1,3),16), g2 = parseInt(color.slice(3,5),16), b = parseInt(color.slice(5,7),16);
      const grad = ctx.createLinearGradient(0, y, 0, H - 20);
      grad.addColorStop(0, `rgba(${r},${g2},${b},0.9)`);
      grad.addColorStop(1, `rgba(${r},${g2},${b},0.3)`);

      ctx.fillStyle = grad;
      ctx.shadowColor = `rgba(${r},${g2},${b},0.4)`;
      ctx.shadowBlur = 8;
      const radius = 4;
      ctx.beginPath();
      ctx.moveTo(x + radius, y);
      ctx.lineTo(x + barW - radius, y);
      ctx.quadraticCurveTo(x + barW, y, x + barW, y + radius);
      ctx.lineTo(x + barW, H - 20);
      ctx.lineTo(x, H - 20);
      ctx.lineTo(x, y + radius);
      ctx.quadraticCurveTo(x, y, x + radius, y);
      ctx.closePath();
      ctx.fill();
      ctx.shadowBlur = 0;

      if (labels) {
        ctx.fillStyle = 'rgba(127,168,191,0.8)';
        ctx.font = '10px Share Tech Mono';
        ctx.textAlign = 'center';
        ctx.fillText(labels[i] || '', x + barW / 2, H - 4);
      }
    });
  },

  drawDonut(canvas, segments, title) {
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const W = canvas.width = canvas.offsetWidth;
    const H = canvas.height = canvas.offsetHeight || 200;
    ctx.clearRect(0, 0, W, H);

    const cx = W / 2, cy = H / 2;
    const R = Math.min(W, H) * 0.38;
    const r = R * 0.65;

    let start = -Math.PI / 2;
    const total = segments.reduce((s, x) => s + x.value, 0);

    segments.forEach(seg => {
      const angle = (seg.value / total) * Math.PI * 2;
      const rv = parseInt(seg.color.slice(1,3),16), gv = parseInt(seg.color.slice(3,5),16), bv = parseInt(seg.color.slice(5,7),16);

      ctx.beginPath();
      ctx.arc(cx, cy, R, start, start + angle);
      ctx.arc(cx, cy, r, start + angle, start, true);
      ctx.closePath();
      ctx.fillStyle = `rgba(${rv},${gv},${bv},0.85)`;
      ctx.shadowColor = `rgba(${rv},${gv},${bv},0.3)`;
      ctx.shadowBlur = 10;
      ctx.fill();
      ctx.shadowBlur = 0;

      // Gap
      ctx.strokeStyle = '#030a0f';
      ctx.lineWidth = 2;
      ctx.stroke();

      start += angle;
    });

    if (title) {
      ctx.fillStyle = '#e8f4f8';
      ctx.font = `bold 18px Rajdhani`;
      ctx.textAlign = 'center';
      ctx.fillText(title, cx, cy + 4);
      ctx.fillStyle = '#7fa8bf';
      ctx.font = '10px Share Tech Mono';
      ctx.fillText('TOTAL', cx, cy + 18);
    }
  },

  drawGauge(canvas, value, max, color, label) {
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const W = canvas.width = canvas.offsetWidth;
    const H = canvas.height = canvas.offsetHeight || 140;
    ctx.clearRect(0, 0, W, H);

    const cx = W / 2, cy = H * 0.7;
    const R = Math.min(W * 0.4, H * 0.65);

    const startAngle = Math.PI * 0.8;
    const endAngle = Math.PI * 2.2;
    const progress = (value / max);
    const valueAngle = startAngle + progress * (endAngle - startAngle);

    // Background arc
    ctx.beginPath();
    ctx.arc(cx, cy, R, startAngle, endAngle);
    ctx.strokeStyle = 'rgba(0,212,255,0.1)';
    ctx.lineWidth = 10;
    ctx.lineCap = 'round';
    ctx.stroke();

    // Value arc
    const rv = parseInt(color.slice(1,3),16), gv = parseInt(color.slice(3,5),16), bv = parseInt(color.slice(5,7),16);
    const grad = ctx.createLinearGradient(cx - R, cy, cx + R, cy);
    grad.addColorStop(0, `rgba(${rv},${gv},${bv},0.5)`);
    grad.addColorStop(1, color);

    ctx.beginPath();
    ctx.arc(cx, cy, R, startAngle, valueAngle);
    ctx.strokeStyle = grad;
    ctx.lineWidth = 10;
    ctx.lineCap = 'round';
    ctx.shadowColor = `rgba(${rv},${gv},${bv},0.5)`;
    ctx.shadowBlur = 12;
    ctx.stroke();
    ctx.shadowBlur = 0;

    // Value text
    ctx.fillStyle = '#e8f4f8';
    ctx.font = `bold ${R * 0.42}px Rajdhani`;
    ctx.textAlign = 'center';
    ctx.fillText(Math.round(value), cx, cy + R * 0.15);

    ctx.fillStyle = '#7fa8bf';
    ctx.font = `${R * 0.18}px Share Tech Mono`;
    ctx.fillText(label, cx, cy + R * 0.42);
  },

  drawHeatmap(canvas, data, rows, cols) {
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const W = canvas.width = canvas.offsetWidth;
    const H = canvas.height = canvas.offsetHeight || 160;
    ctx.clearRect(0, 0, W, H);

    const cw = W / cols, ch = H / rows;

    data.forEach((v, i) => {
      const row = Math.floor(i / cols), col = i % cols;
      const norm = Math.max(0, Math.min(1, v / 100));
      let r, g, b;
      if (norm < 0.5) { r = Math.round(norm * 2 * 255); g = 255; b = 0; }
      else { r = 255; g = Math.round((1 - (norm - 0.5) * 2) * 255); b = 0; }

      ctx.fillStyle = `rgba(${r},${g},${b},0.75)`;
      ctx.fillRect(col * cw + 2, row * ch + 2, cw - 4, ch - 4);

      if (cw > 30) {
        ctx.fillStyle = 'rgba(255,255,255,0.7)';
        ctx.font = '9px Share Tech Mono';
        ctx.textAlign = 'center';
        ctx.fillText(Math.round(v), col * cw + cw / 2, row * ch + ch / 2 + 3);
      }
    });
  },

  drawScatter(canvas, points) {
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const W = canvas.width = canvas.offsetWidth;
    const H = canvas.height = canvas.offsetHeight || 200;
    ctx.clearRect(0, 0, W, H);

    const xs = points.map(p => p.x), ys = points.map(p => p.y);
    const xMin = Math.min(...xs), xMax = Math.max(...xs);
    const yMin = Math.min(...ys), yMax = Math.max(...ys);

    const pad = 20;
    const toX = v => pad + ((v - xMin) / (xMax - xMin || 1)) * (W - 2 * pad);
    const toY = v => H - pad - ((v - yMin) / (yMax - yMin || 1)) * (H - 2 * pad);

    // Grid
    ctx.strokeStyle = 'rgba(0,212,255,0.05)';
    for (let i = 0; i <= 4; i++) {
      ctx.beginPath(); ctx.moveTo(pad + (i / 4) * (W - 2*pad), pad); ctx.lineTo(pad + (i / 4) * (W - 2*pad), H - pad); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(pad, pad + (i / 4) * (H - 2*pad)); ctx.lineTo(W - pad, pad + (i / 4) * (H - 2*pad)); ctx.stroke();
    }

    points.forEach(p => {
      const color = p.color || '#00d4ff';
      const rv = parseInt(color.slice(1,3),16), gv = parseInt(color.slice(3,5),16), bv = parseInt(color.slice(5,7),16);
      ctx.beginPath();
      ctx.arc(toX(p.x), toY(p.y), 4, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(${rv},${gv},${bv},0.8)`;
      ctx.shadowColor = `rgba(${rv},${gv},${bv},0.4)`;
      ctx.shadowBlur = 6;
      ctx.fill();
      ctx.shadowBlur = 0;
    });
  }
};

// ============================================================
// NAVIGATION
// ============================================================
function navigate(pageId) {
  document.querySelectorAll('.page-content').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));

  const page = document.getElementById(pageId);
  if (page) {
    page.classList.add('active');
    APP.currentPage = pageId;
    const navItem = document.querySelector(`[data-page="${pageId}"]`);
    if (navItem) navItem.classList.add('active');
    loadPageData(pageId);
    document.querySelector('.header-title').innerHTML = getPageTitle(pageId);
    window.scrollTo(0, 0);
  }
}

function getPageTitle(pageId) {
  const titles = {
    'dashboard': '⚡ System <span>Dashboard</span>',
    'machines': '🏭 Machine <span>Fleet</span>',
    'predictions': '🧠 AI <span>Predictions</span>',
    'alerts': '🚨 Alert <span>Center</span>',
    'sensors': '📡 Sensor <span>Data</span>',
    'analytics': '📊 Advanced <span>Analytics</span>',
    'maintenance': '🔧 Maintenance <span>Scheduler</span>',
    'models': '🤖 AI <span>Models</span>',
    'reports': '📋 <span>Reports</span>',
    'settings': '⚙️ System <span>Settings</span>',
    'users': '👥 User <span>Management</span>',
    'audit': '🔒 Audit <span>Log</span>',
    // User pages
    'u-dashboard': '⚡ My <span>Dashboard</span>',
    'u-my-machines': '🏭 My <span>Machines</span>',
    'u-predictions': '🧠 <span>Predictions</span>',
    'u-alerts': '🚨 My <span>Alerts</span>',
    'u-sensors': '📡 Live <span>Sensors</span>',
    'u-workorders': '📋 Work <span>Orders</span>',
    'u-schedule': '📅 My <span>Schedule</span>',
    'u-reports': '📊 My <span>Reports</span>',
    'u-history': '📜 Fault <span>History</span>',
    'u-training': '🎓 <span>Training</span>',
    'u-profile': '👤 My <span>Profile</span>',
    'u-support': '🆘 <span>Support</span>',
  };
  return titles[pageId] || '⚡ <span>Dashboard</span>';
}

// ============================================================
// PAGE DATA LOADERS
// ============================================================
function loadPageData(pageId) {
  clearIntervals();
  setTimeout(() => {
    switch(pageId) {
      case 'dashboard': loadDashboard(); break;
      case 'machines': loadMachines(); break;
      case 'predictions': loadPredictions(); break;
      case 'alerts': loadAlerts(); break;
      case 'sensors': loadSensors(); break;
      case 'analytics': loadAnalytics(); break;
      case 'maintenance': loadMaintenance(); break;
      case 'models': loadModels(); break;
      case 'reports': loadReports(); break;
      case 'u-dashboard': loadUserDashboard(); break;
      case 'u-my-machines': loadUserMachines(); break;
      case 'u-predictions': loadUserPredictions(); break;
      case 'u-alerts': loadUserAlerts(); break;
      case 'u-sensors': loadUserSensors(); break;
      case 'u-workorders': loadWorkOrders(); break;
      case 'u-schedule': loadSchedule(); break;
      case 'u-reports': loadUserReports(); break;
      case 'u-history': loadFaultHistory(); break;
      case 'u-training': loadTraining(); break;
    }
  }, 80);
}

function clearIntervals() {
  APP.updateIntervals.forEach(id => clearInterval(id));
  APP.updateIntervals = [];
}

// ============================================================
// ADMIN: DASHBOARD
// ============================================================
function loadDashboard() {
  renderDashboardKPIs();
  renderDashboardCharts();
  renderMachineTable();
  renderAlertSummary();

  const id = setInterval(() => {
    if (APP.currentPage !== 'dashboard') return;
    updateLiveKPIs();
  }, 3000);
  APP.updateIntervals.push(id);
}

function renderDashboardKPIs() {
  const el = document.getElementById('dash-kpis');
  if (!el) return;
  el.innerHTML = `
    <div class="kpi-card fade-in">
      <div class="kpi-icon">🏭</div>
      <div class="kpi-label">Total Machines</div>
      <div class="kpi-value cyan" id="kpi-machines">8</div>
      <div class="kpi-trend up">▲ All Monitored</div>
    </div>
    <div class="kpi-card fade-in">
      <div class="kpi-icon">⚠️</div>
      <div class="kpi-label">Active Alerts</div>
      <div class="kpi-value red" id="kpi-alerts">5</div>
      <div class="kpi-trend down">▲ 2 Critical</div>
    </div>
    <div class="kpi-card fade-in">
      <div class="kpi-icon">💚</div>
      <div class="kpi-label">Overall Health</div>
      <div class="kpi-value green" id="kpi-health">74%</div>
      <div class="kpi-trend down">▼ -3.2% vs last week</div>
    </div>
    <div class="kpi-card fade-in">
      <div class="kpi-icon">🧠</div>
      <div class="kpi-label">AI Predictions</div>
      <div class="kpi-value orange" id="kpi-predictions">4</div>
      <div class="kpi-trend">Active Risk Models</div>
    </div>
    <div class="kpi-card fade-in">
      <div class="kpi-icon">⏱️</div>
      <div class="kpi-label">Avg Uptime</div>
      <div class="kpi-value cyan" id="kpi-uptime">96.4%</div>
      <div class="kpi-trend up">▲ +0.8% vs last month</div>
    </div>
    <div class="kpi-card fade-in">
      <div class="kpi-icon">💰</div>
      <div class="kpi-label">Savings (MTD)</div>
      <div class="kpi-value green" id="kpi-savings">$84.2K</div>
      <div class="kpi-trend up">▲ Downtime prevented</div>
    </div>
    <div class="kpi-card fade-in">
      <div class="kpi-icon">🔧</div>
      <div class="kpi-label">Open Work Orders</div>
      <div class="kpi-value yellow" id="kpi-wo">12</div>
      <div class="kpi-trend">3 Urgent, 9 Scheduled</div>
    </div>
    <div class="kpi-card fade-in">
      <div class="kpi-icon">🎯</div>
      <div class="kpi-label">Model Accuracy</div>
      <div class="kpi-value purple" id="kpi-accuracy">94.7%</div>
      <div class="kpi-trend up">▲ F1 Score 0.94</div>
    </div>
  `;
}

function updateLiveKPIs() {
  const updates = [
    ['kpi-health', () => `${(72 + Math.random() * 4).toFixed(1)}%`],
    ['kpi-uptime', () => `${(95.8 + Math.random() * 1.2).toFixed(1)}%`],
    ['kpi-savings', () => `$${(82 + Math.random() * 4).toFixed(1)}K`],
    ['kpi-accuracy', () => `${(93.5 + Math.random() * 2).toFixed(1)}%`],
  ];
  updates.forEach(([id, fn]) => {
    const el = document.getElementById(id);
    if (el) { el.style.transition = 'opacity 0.3s'; el.style.opacity = '0.4'; setTimeout(() => { el.textContent = fn(); el.style.opacity = '1'; }, 200); }
  });
}

function renderDashboardCharts() {
  setTimeout(() => {
    const tempCanvas = document.getElementById('dash-temp-chart');
    const vibCanvas = document.getElementById('dash-vib-chart');
    const healthCanvas = document.getElementById('dash-health-chart');
    const alertDonut = document.getElementById('dash-alert-donut');

    if (tempCanvas) CHART.drawMultiLine(tempCanvas, [
      { data: SENSORS.getHistoricalData(24, 75, 10).map(d=>d.v), color: '#00d4ff' },
      { data: SENSORS.getHistoricalData(24, 85, 8).map(d=>d.v), color: '#ff6b00' },
      { data: SENSORS.getHistoricalData(24, 65, 6).map(d=>d.v), color: '#00ff88' },
    ]);

    if (vibCanvas) CHART.drawLine(vibCanvas, SENSORS.getHistoricalData(48, 2.4, 1.5), '#ff6b00');

    if (healthCanvas) CHART.drawBar(
      healthCanvas,
      SENSORS.machines.map(m => m.id),
      SENSORS.machines.map(m => m.health),
      SENSORS.machines.map(m => m.health < 50 ? '#ff2d55' : m.health < 70 ? '#ff6b00' : '#00ff88')
    );

    if (alertDonut) CHART.drawDonut(alertDonut, [
      { value: 2, color: '#ff2d55', label: 'Critical' },
      { value: 3, color: '#ff6b00', label: 'Warning' },
      { value: 5, color: '#ffd600', label: 'Caution' },
      { value: 8, color: '#00d4ff', label: 'Info' },
    ], '18');
  }, 100);
}

function renderMachineTable() {
  const el = document.getElementById('dash-machine-table');
  if (!el) return;
  const rows = SENSORS.machines.map(m => `
    <tr>
      <td><b>${m.id}</b></td>
      <td>${m.name}</td>
      <td>${m.type}</td>
      <td>${m.plant}</td>
      <td>
        <div style="display:flex;align-items:center;gap:8px;">
          <div class="progress-bar" style="width:80px;flex-shrink:0">
            <div class="progress-fill" style="width:${m.health}%;background:${m.health<50?'var(--accent-red)':m.health<70?'var(--accent-orange)':'var(--accent-green)'}"></div>
          </div>
          <span style="font-family:'Share Tech Mono',monospace;font-size:12px">${m.health}%</span>
        </div>
      </td>
      <td><span class="badge badge-${m.status==='good'?'good':m.status==='warning'?'warning':'critical'}">${m.status}</span></td>
      <td>
        <button class="btn btn-secondary btn-sm" onclick="navigate('sensors')">📡 Live</button>
      </td>
    </tr>
  `).join('');
  el.innerHTML = rows;
}

function renderAlertSummary() {
  const el = document.getElementById('dash-alerts');
  if (!el) return;
  const alerts = SENSORS.getAlerts().slice(0, 4);
  el.innerHTML = alerts.map(a => `
    <div class="alert alert-${a.type}">
      <div class="alert-icon">${a.type==='critical'?'🔴':a.type==='warning'?'🟡':'🔵'}</div>
      <div class="alert-body">
        <div class="alert-title">${a.machine}</div>
        <div class="alert-text">${a.msg}</div>
        <div class="alert-time">${a.time} ${a.ack ? '· ✓ Acknowledged' : '· <b style="color:var(--accent-orange)">Unacknowledged</b>'}</div>
      </div>
    </div>
  `).join('');
}

// ============================================================
// ADMIN: MACHINES
// ============================================================
function loadMachines() {
  const el = document.getElementById('machines-grid');
  if (!el) return;
  el.innerHTML = SENSORS.machines.map(m => `
    <div class="machine-card fade-in" onclick="showMachineModal('${m.id}')">
      <div class="machine-header">
        <div class="machine-icon">⚙️</div>
        <div>
          <div class="machine-id">${m.id} · ${m.plant}</div>
          <div class="machine-name">${m.name}</div>
        </div>
        <span class="badge badge-${m.status==='good'?'good':m.status==='warning'?'warning':'critical'}" style="margin-left:auto">${m.status}</span>
      </div>
      <div style="font-size:12px;color:var(--text-muted);margin-bottom:12px">Type: ${m.type}</div>
      <div class="health-bar">
        <div class="health-label"><span>Health Index</span><span>${m.health}%</span></div>
        <div class="progress-bar">
          <div class="progress-fill" style="width:${m.health}%;background:${m.health<50?'var(--accent-red)':m.health<70?'var(--accent-orange)':'var(--accent-green)'}"></div>
        </div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:14px;font-size:12px">
        <div style="background:var(--bg-secondary);border-radius:6px;padding:8px;text-align:center">
          <div style="color:var(--text-muted);font-family:'Share Tech Mono',monospace;font-size:10px;margin-bottom:3px">TEMP</div>
          <div style="color:var(--accent-orange);font-family:'Rajdhani',sans-serif;font-size:18px;font-weight:700" class="live-temp-${m.id}">${(70+Math.random()*20).toFixed(1)}°C</div>
        </div>
        <div style="background:var(--bg-secondary);border-radius:6px;padding:8px;text-align:center">
          <div style="color:var(--text-muted);font-family:'Share Tech Mono',monospace;font-size:10px;margin-bottom:3px">VIBRATION</div>
          <div style="color:var(--accent-cyan);font-family:'Rajdhani',sans-serif;font-size:18px;font-weight:700" class="live-vib-${m.id}">${(1.5+Math.random()*3).toFixed(2)} mm/s</div>
        </div>
      </div>
    </div>
  `).join('');

  const updId = setInterval(() => {
    if (APP.currentPage !== 'machines') return;
    SENSORS.machines.forEach(m => {
      const data = SENSORS.getLiveSensorData(m.id);
      const tEl = document.querySelector(`.live-temp-${m.id}`);
      const vEl = document.querySelector(`.live-vib-${m.id}`);
      if (tEl) tEl.textContent = `${data.temperature}°C`;
      if (vEl) vEl.textContent = `${data.vibration} mm/s`;
    });
  }, 2500);
  APP.updateIntervals.push(updId);
}

function showMachineModal(id) {
  const m = SENSORS.machines.find(x => x.id === id);
  if (!m) return;
  const data = SENSORS.getLiveSensorData(id);
  const modal = document.getElementById('machine-modal');
  if (!modal) return;

  document.getElementById('modal-machine-title').textContent = `${m.name} — ${m.id}`;
  const content = document.getElementById('modal-machine-body');
  content.innerHTML = `
    <div class="sensor-grid">
      ${Object.entries(data).map(([k, v]) => `
        <div class="sensor-card">
          <div class="sensor-name">${k.replace(/_/g,' ')}</div>
          <div class="sensor-value" style="color:var(--accent-cyan)">${v}</div>
          <div class="sensor-unit">${getSensorUnit(k)}</div>
        </div>
      `).join('')}
    </div>
  `;
  modal.classList.add('open');
}

function getSensorUnit(k) {
  const units = { temperature: '°C', vibration: 'mm/s', pressure: 'PSI', rpm: 'RPM', current: 'A', noise: 'dB', oil_pressure: 'PSI', humidity: '%RH', voltage: 'V', flow_rate: 'L/min', torque: 'Nm', efficiency: '%' };
  return units[k] || '';
}

// ============================================================
// ADMIN: PREDICTIONS
// ============================================================
function loadPredictions() {
  const el = document.getElementById('predictions-list');
  if (!el) return;
  const preds = SENSORS.getPredictions();
  el.innerHTML = preds.map(p => `
    <div class="prediction-card ${p.severity} fade-in">
      <div class="prediction-header">
        <div>
          <div class="prediction-title">${p.machine}</div>
          <div style="font-size:12px;color:var(--text-secondary);margin-top:2px">⚙️ ${p.type}</div>
        </div>
        <div class="prediction-prob">${p.probability}%</div>
      </div>
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-top:12px">
        <div style="text-align:center;background:rgba(0,0,0,0.2);padding:10px;border-radius:8px">
          <div style="font-size:10px;color:var(--text-muted);font-family:'Share Tech Mono',monospace;margin-bottom:4px">FAILURE ETA</div>
          <div style="font-family:'Rajdhani',sans-serif;font-size:18px;font-weight:700;color:var(--text-primary)">${p.eta}</div>
        </div>
        <div style="text-align:center;background:rgba(0,0,0,0.2);padding:10px;border-radius:8px">
          <div style="font-size:10px;color:var(--text-muted);font-family:'Share Tech Mono',monospace;margin-bottom:4px">CONFIDENCE</div>
          <div style="font-family:'Rajdhani',sans-serif;font-size:18px;font-weight:700;color:var(--accent-cyan)">${p.confidence}%</div>
        </div>
        <div style="text-align:center;background:rgba(0,0,0,0.2);padding:10px;border-radius:8px">
          <div style="font-size:10px;color:var(--text-muted);font-family:'Share Tech Mono',monospace;margin-bottom:4px">RUL</div>
          <div style="font-family:'Rajdhani',sans-serif;font-size:18px;font-weight:700;color:var(--accent-yellow)">${p.rul}</div>
        </div>
      </div>
      <div style="margin-top:14px;display:flex;gap:8px">
        <button class="btn btn-danger btn-sm">🚨 Create Work Order</button>
        <button class="btn btn-secondary btn-sm">📊 View Details</button>
        <button class="btn btn-success btn-sm">✅ Acknowledge</button>
      </div>
    </div>
  `).join('');

  // RUL Chart
  setTimeout(() => {
    const rulCanvas = document.getElementById('rul-chart');
    if (rulCanvas) {
      const data = [];
      for (let i = 0; i < 30; i++) {
        const base = 100 - i * 2.5 + (Math.random() - 0.5) * 8;
        data.push(Math.max(0, base));
      }
      CHART.drawLine(rulCanvas, data, '#ff6b00');
    }
    const probCanvas = document.getElementById('prob-trend-chart');
    if (probCanvas) {
      CHART.drawMultiLine(probCanvas, [
        { data: Array.from({length:30},(_,i) => Math.min(95, 20 + i*2.5 + (Math.random()-0.5)*5)), color: '#ff2d55' },
        { data: Array.from({length:30},(_,i) => Math.min(80, 10 + i*2 + (Math.random()-0.5)*4)), color: '#ff6b00' },
        { data: Array.from({length:30},(_,i) => Math.min(65, 5 + i*1.8 + (Math.random()-0.5)*3)), color: '#ffd600' },
      ]);
    }
  }, 150);
}

// ============================================================
// ADMIN: ALERTS
// ============================================================
function loadAlerts() {
  const el = document.getElementById('alerts-list');
  if (!el) return;
  const alerts = SENSORS.getAlerts();
  el.innerHTML = alerts.map(a => `
    <div class="alert alert-${a.type} fade-in" style="margin-bottom:12px;border-radius:10px;padding:16px">
      <div class="alert-icon" style="font-size:22px">${a.type==='critical'?'🔴':a.type==='warning'?'🟡':'🔵'}</div>
      <div class="alert-body">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px">
          <span class="badge badge-${a.type==='critical'?'critical':a.type==='warning'?'warning':'info'}">${a.type.toUpperCase()}</span>
          <span style="font-weight:700;color:var(--text-primary)">${a.machine}</span>
          ${!a.ack ? '<span style="font-size:11px;color:var(--accent-orange);font-family:\'Share Tech Mono\',monospace">● UNACKNOWLEDGED</span>' : ''}
        </div>
        <div class="alert-text">${a.msg}</div>
        <div style="display:flex;align-items:center;justify-content:space-between;margin-top:10px">
          <span class="alert-time">${a.time}</span>
          <div style="display:flex;gap:6px">
            ${!a.ack ? `<button class="btn btn-secondary btn-sm" onclick="this.closest('.alert').style.opacity='0.5'">✓ Acknowledge</button>` : ''}
            <button class="btn btn-danger btn-sm">🔧 Work Order</button>
          </div>
        </div>
      </div>
    </div>
  `).join('');
}

// ============================================================
// ADMIN: SENSORS
// ============================================================
function loadSensors() {
  const machineSelect = document.getElementById('sensor-machine-select');
  if (machineSelect && !machineSelect.dataset.initialized) {
    machineSelect.innerHTML = SENSORS.machines.map(m => `<option value="${m.id}">${m.id} - ${m.name}</option>`).join('');
    machineSelect.dataset.initialized = '1';
  }

  updateSensorGrid('M-001');
  updateSensorCharts('M-001');

  if (machineSelect) {
    machineSelect.onchange = (e) => {
      updateSensorGrid(e.target.value);
      updateSensorCharts(e.target.value);
    };
  }

  const liveId = setInterval(() => {
    if (APP.currentPage !== 'sensors' && APP.currentPage !== 'u-sensors') return;
    const sel = document.getElementById('sensor-machine-select');
    const id = sel ? sel.value : 'M-001';
    updateSensorGrid(id);
    updateStreamLog();
  }, 2000);
  APP.updateIntervals.push(liveId);
}

function updateSensorGrid(machineId) {
  const el = document.getElementById('live-sensor-grid');
  if (!el) return;
  const data = SENSORS.getLiveSensorData(machineId);
  const colorMap = { temperature: '#ff6b00', vibration: '#ff2d55', pressure: '#00d4ff', rpm: '#a855f7', current: '#ffd600', noise: '#ff6b00', oil_pressure: '#00ff88', humidity: '#00d4ff', voltage: '#ffd600', flow_rate: '#a855f7', torque: '#ff6b00', efficiency: '#00ff88' };

  el.innerHTML = Object.entries(data).map(([k, v]) => `
    <div class="sensor-card">
      <div class="sensor-name">${k.replace(/_/g,' ').toUpperCase()}</div>
      <div class="sensor-value" style="color:${colorMap[k]||'var(--accent-cyan)'}">${v}</div>
      <div class="sensor-unit">${getSensorUnit(k)}</div>
      <div class="sensor-status"><span class="badge badge-good">LIVE</span></div>
    </div>
  `).join('');
}

function updateSensorCharts(machineId) {
  setTimeout(() => {
    const c1 = document.getElementById('sensor-temp-chart');
    const c2 = document.getElementById('sensor-vib-chart');
    const c3 = document.getElementById('sensor-pressure-chart');
    const c4 = document.getElementById('sensor-rpm-chart');
    if (c1) CHART.drawLine(c1, SENSORS.getHistoricalData(60, 75, 12), '#ff6b00');
    if (c2) CHART.drawLine(c2, SENSORS.getHistoricalData(60, 2.4, 1.5), '#ff2d55');
    if (c3) CHART.drawLine(c3, SENSORS.getHistoricalData(60, 145, 15), '#00d4ff');
    if (c4) CHART.drawLine(c4, SENSORS.getHistoricalData(60, 1450, 80), '#a855f7');
  }, 120);
}

function updateStreamLog() {
  const el = document.getElementById('data-stream-log');
  if (!el) return;
  const now = new Date().toISOString().split('.')[0];
  const data = SENSORS.getLiveSensorData('M-001');
  const line = document.createElement('div');
  line.className = 'stream-line';
  line.textContent = `[${now}Z] TEMP:${data.temperature}°C VIB:${data.vibration}mm/s PRES:${data.pressure}PSI RPM:${data.rpm} CUR:${data.current}A`;
  el.appendChild(line);
  if (el.children.length > 20) el.removeChild(el.firstChild);
  el.scrollTop = el.scrollHeight;
}

// ============================================================
// ADMIN: ANALYTICS
// ============================================================
function loadAnalytics() {
  setTimeout(() => {
    const c1 = document.getElementById('analytics-oee');
    const c2 = document.getElementById('analytics-failure-modes');
    const c3 = document.getElementById('analytics-mttr');
    const c4 = document.getElementById('analytics-cost');
    const c5 = document.getElementById('analytics-heatmap');
    const c6 = document.getElementById('analytics-scatter');
    const c7 = document.getElementById('analytics-trend');

    if (c1) CHART.drawGauge(c1, 82.4, 100, '#00d4ff', 'OEE %');
    if (c2) CHART.drawBar(c2, ['Bearing','Seal','Corrosion','Fatigue','Electrical','Thermal'],
      [34, 22, 18, 14, 8, 4], ['#ff2d55','#ff6b00','#ffd600','#00d4ff','#a855f7','#00ff88']);
    if (c3) CHART.drawBar(c3, ['Jan','Feb','Mar','Apr','May','Jun'],
      [4.2,3.8,5.1,3.2,4.8,2.9], '#00d4ff');
    if (c4) CHART.drawMultiLine(c4, [
      { data: Array.from({length:12},()=>SENSORS.generateReading(45000,8000)), color: '#ff2d55' },
      { data: Array.from({length:12},()=>SENSORS.generateReading(28000,5000)), color: '#00ff88' },
    ]);
    if (c5) {
      const hm = Array.from({length:48}, () => Math.random() * 100);
      CHART.drawHeatmap(c5, hm, 6, 8);
    }
    if (c6) {
      const pts = Array.from({length:80}, () => ({
        x: SENSORS.generateReading(50, 40),
        y: SENSORS.generateReading(50, 40),
        color: Math.random() > 0.7 ? '#ff2d55' : Math.random() > 0.5 ? '#ff6b00' : '#00d4ff'
      }));
      CHART.drawScatter(c6, pts);
    }
    if (c7) CHART.drawMultiLine(c7, [
      { data: Array.from({length:30},()=>SENSORS.generateReading(88,6)), color: '#00ff88' },
      { data: Array.from({length:30},(_,i)=>Math.max(0, 95 - i*1.2 + SENSORS.generateReading(0,4))), color: '#ff6b00' },
    ]);
  }, 150);
}

// ============================================================
// ADMIN: MAINTENANCE
// ============================================================
function loadMaintenance() {
  const el = document.getElementById('maintenance-schedule');
  if (!el) return;
  const tasks = [
    { id: 'WO-1042', machine: 'M-003 Compressor Unit 3', type: 'Corrective', priority: 'CRITICAL', due: 'TODAY', tech: 'James K.', status: 'In Progress', est: '4 hrs' },
    { id: 'WO-1043', machine: 'M-002 Pump Station A', type: 'Predictive', priority: 'HIGH', due: 'Tomorrow', tech: 'Sarah M.', status: 'Scheduled', est: '2.5 hrs' },
    { id: 'WO-1044', machine: 'M-006 Turbine Gen-1', type: 'Predictive', priority: 'MEDIUM', due: 'May 10', tech: 'Robert L.', status: 'Planned', est: '6 hrs' },
    { id: 'WO-1041', machine: 'M-001 CNC Mill #1', type: 'Preventive', priority: 'LOW', due: 'May 7', tech: 'Ana P.', status: 'Scheduled', est: '1.5 hrs' },
    { id: 'WO-1040', machine: 'M-008 Heat Exchanger', type: 'Predictive', priority: 'MEDIUM', due: 'May 15', tech: 'David C.', status: 'Planned', est: '3 hrs' },
    { id: 'WO-1039', machine: 'M-004 Conveyor B2', type: 'Preventive', priority: 'LOW', due: 'May 20', tech: 'Lisa N.', status: 'Planned', est: '1 hr' },
  ];

  el.innerHTML = `
    <table class="data-table">
      <thead><tr><th>WO ID</th><th>Machine</th><th>Type</th><th>Priority</th><th>Due</th><th>Technician</th><th>Status</th><th>Est. Time</th><th>Actions</th></tr></thead>
      <tbody>
        ${tasks.map(t => `
          <tr>
            <td><b style="color:var(--accent-cyan)">${t.id}</b></td>
            <td>${t.machine}</td>
            <td><span class="badge badge-info">${t.type}</span></td>
            <td><span class="badge badge-${t.priority==='CRITICAL'?'critical':t.priority==='HIGH'?'warning':t.priority==='MEDIUM'?'maintenance':'good'}">${t.priority}</span></td>
            <td style="font-family:'Share Tech Mono',monospace;font-size:12px">${t.due}</td>
            <td>${t.tech}</td>
            <td><span class="badge badge-${t.status==='In Progress'?'warning':t.status==='Scheduled'?'info':'offline'}">${t.status}</span></td>
            <td style="font-family:'Share Tech Mono',monospace">${t.est}</td>
            <td><button class="btn btn-secondary btn-sm">📋 View</button></td>
          </tr>
        `).join('')}
      </tbody>
    </table>
  `;
}

// ============================================================
// ADMIN: AI MODELS
// ============================================================
function loadModels() {
  setTimeout(() => {
    const c1 = document.getElementById('model-roc');
    const c2 = document.getElementById('model-confusion');
    const c3 = document.getElementById('model-importance');
    const c4 = document.getElementById('model-accuracy-trend');

    if (c1) {
      const rocPts = [];
      let x = 0;
      for (let i = 0; i <= 20; i++) {
        x = i / 20;
        rocPts.push({ x: x * 100, y: Math.min(100, Math.pow(x, 0.3) * 110), color: '#00d4ff' });
      }
      CHART.drawScatter(c1, rocPts);
    }
    if (c2) CHART.drawHeatmap(c2, [95,3,2,1,4,92,3,1,2,3,91,4,1,2,4,93], 4, 4);
    if (c3) CHART.drawBar(c3, ['Vibration','Temperature','Current','Pressure','RPM','Noise','Oil Pres.','Torque'],
      [0.34,0.28,0.14,0.10,0.06,0.04,0.02,0.02].map(v=>v*100), '#a855f7');
    if (c4) CHART.drawMultiLine(c4, [
      { data: Array.from({length:20},()=>SENSORS.generateReading(94,2)), color: '#00ff88' },
      { data: Array.from({length:20},()=>SENSORS.generateReading(91,3)), color: '#00d4ff' },
      { data: Array.from({length:20},()=>SENSORS.generateReading(88,3)), color: '#a855f7' },
    ]);
  }, 150);
}

// ============================================================
// ADMIN: REPORTS
// ============================================================
function loadReports() {
  setTimeout(() => {
    const c1 = document.getElementById('report-monthly');
    const c2 = document.getElementById('report-savings');
    if (c1) CHART.drawBar(c1, ['Jan','Feb','Mar','Apr','May'],
      [3,5,2,4,1], ['#ff2d55','#ff6b00','#ffd600','#00d4ff','#00ff88']);
    if (c2) CHART.drawLine(c2, [22000,31000,28000,45000,38000,52000,61000,58000,72000,68000,79000,84200], '#00ff88');
  }, 150);
}

// ============================================================
// USER: DASHBOARD
// ============================================================
function loadUserDashboard() {
  const el = document.getElementById('user-dash-kpis');
  if (el) {
    el.innerHTML = `
      <div class="kpi-card fade-in">
        <div class="kpi-icon">🏭</div>
        <div class="kpi-label">My Machines</div>
        <div class="kpi-value cyan">4</div>
        <div class="kpi-trend">Assigned to me</div>
      </div>
      <div class="kpi-card fade-in">
        <div class="kpi-icon">📋</div>
        <div class="kpi-label">Open Work Orders</div>
        <div class="kpi-value orange">3</div>
        <div class="kpi-trend down">2 Due Today</div>
      </div>
      <div class="kpi-card fade-in">
        <div class="kpi-icon">⚠️</div>
        <div class="kpi-label">My Alerts</div>
        <div class="kpi-value red">2</div>
        <div class="kpi-trend down">Requires Action</div>
      </div>
      <div class="kpi-card fade-in">
        <div class="kpi-icon">✅</div>
        <div class="kpi-label">Completed Today</div>
        <div class="kpi-value green">5</div>
        <div class="kpi-trend up">▲ Great Progress!</div>
      </div>
    `;
  }

  setTimeout(() => {
    const c = document.getElementById('user-activity-chart');
    if (c) CHART.drawBar(c, ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],
      [3,5,4,7,6,2,1], '#00d4ff');
  }, 120);
}

function loadUserMachines() { loadMachines(); }
function loadUserPredictions() { loadPredictions(); }
function loadUserAlerts() { loadAlerts(); }
function loadUserSensors() { loadSensors(); }

// ============================================================
// USER: WORK ORDERS
// ============================================================
function loadWorkOrders() { loadMaintenance(); }

// ============================================================
// USER: SCHEDULE
// ============================================================
function loadSchedule() {
  const el = document.getElementById('schedule-content');
  if (!el) return;
  const today = new Date();
  const days = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  const tasks = [
    { day: 1, title: 'Inspect M-003 Compressor', time: '08:00 - 10:00', priority: 'critical' },
    { day: 1, title: 'Replace Bearing M-003', time: '10:30 - 14:00', priority: 'critical' },
    { day: 2, title: 'PM Check M-002 Pump', time: '09:00 - 11:30', priority: 'warning' },
    { day: 3, title: 'Oil Change M-005 Press', time: '14:00 - 15:00', priority: 'info' },
    { day: 4, title: 'Vibration Analysis M-006', time: '11:00 - 13:00', priority: 'warning' },
    { day: 5, title: 'Calibration M-001 CNC', time: '08:30 - 09:30', priority: 'info' },
  ];

  el.innerHTML = `
    <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:8px">
      ${Array.from({length:7},(_,i) => {
        const d = new Date(today); d.setDate(today.getDate() + i);
        const dayTasks = tasks.filter(t => t.day === i+1);
        return `
          <div style="background:var(--bg-card2);border:1px solid var(--border);border-radius:10px;padding:12px;min-height:140px">
            <div style="font-size:11px;color:var(--text-muted);font-family:'Share Tech Mono',monospace">${days[d.getDay()]}</div>
            <div style="font-family:'Rajdhani',sans-serif;font-size:22px;font-weight:700;margin:2px 0 10px;color:${i===0?'var(--accent-cyan)':'var(--text-primary)'}">${d.getDate()}</div>
            ${dayTasks.map(t=>`
              <div style="background:rgba(0,212,255,0.08);border-left:3px solid ${t.priority==='critical'?'var(--accent-red)':t.priority==='warning'?'var(--accent-orange)':'var(--accent-cyan)'};padding:6px 8px;border-radius:0 6px 6px 0;margin-bottom:6px;font-size:11px">
                <div style="color:var(--text-primary);font-weight:600">${t.title}</div>
                <div style="color:var(--text-muted);font-family:'Share Tech Mono',monospace;margin-top:2px">${t.time}</div>
              </div>
            `).join('')}
          </div>
        `;
      }).join('')}
    </div>
  `;
}

// ============================================================
// USER: REPORTS
// ============================================================
function loadUserReports() {
  setTimeout(() => {
    const c1 = document.getElementById('user-report-chart');
    if (c1) CHART.drawLine(c1, Array.from({length:30},()=>SENSORS.generateReading(85,10)), '#00d4ff');
  }, 120);
}

// ============================================================
// USER: FAULT HISTORY
// ============================================================
function loadFaultHistory() {
  const el = document.getElementById('fault-history-list');
  if (!el) return;
  const faults = [
    { date: '2026-04-28', machine: 'M-003 Compressor', fault: 'Bearing Failure', severity: 'critical', action: 'Replaced bearing assembly', downtime: '8.5 hrs', cost: '$4,200' },
    { date: '2026-04-15', machine: 'M-002 Pump Station', fault: 'Seal Leak', severity: 'warning', action: 'Replaced mechanical seal', downtime: '3.2 hrs', cost: '$850' },
    { date: '2026-03-22', machine: 'M-006 Turbine', fault: 'Blade Erosion', severity: 'warning', action: 'Blade re-profile service', downtime: '12 hrs', cost: '$8,400' },
    { date: '2026-03-10', machine: 'M-001 CNC Mill', fault: 'Spindle Vibration', severity: 'info', action: 'Balancing and alignment', downtime: '1.5 hrs', cost: '$380' },
    { date: '2026-02-18', machine: 'M-008 Heat Exchanger', fault: 'Fouling', severity: 'warning', action: 'Chemical flush and clean', downtime: '4 hrs', cost: '$1,100' },
  ];

  el.innerHTML = `
    <table class="data-table">
      <thead><tr><th>Date</th><th>Machine</th><th>Fault Type</th><th>Severity</th><th>Action Taken</th><th>Downtime</th><th>Cost</th></tr></thead>
      <tbody>
        ${faults.map(f=>`
          <tr>
            <td style="font-family:'Share Tech Mono',monospace">${f.date}</td>
            <td>${f.machine}</td>
            <td>${f.fault}</td>
            <td><span class="badge badge-${f.severity==='critical'?'critical':f.severity==='warning'?'warning':'info'}">${f.severity}</span></td>
            <td>${f.action}</td>
            <td style="color:var(--accent-orange)">${f.downtime}</td>
            <td style="color:var(--accent-red)">${f.cost}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>
  `;
}

// ============================================================
// USER: TRAINING
// ============================================================
function loadTraining() {
  const el = document.getElementById('training-modules');
  if (!el) return;
  const modules = [
    { title: 'Predictive Maintenance Fundamentals', progress: 100, duration: '2.5 hrs', status: 'completed' },
    { title: 'Vibration Analysis & Bearing Diagnostics', progress: 75, duration: '3 hrs', status: 'in-progress' },
    { title: 'Thermography & Infrared Analysis', progress: 45, duration: '2 hrs', status: 'in-progress' },
    { title: 'CMMS Work Order Management', progress: 0, duration: '1.5 hrs', status: 'not-started' },
    { title: 'AI-Assisted Fault Detection', progress: 0, duration: '4 hrs', status: 'not-started' },
    { title: 'Safety & Lockout/Tagout Procedures', progress: 100, duration: '1 hr', status: 'completed' },
  ];

  el.innerHTML = modules.map(m => `
    <div class="card fade-in" style="margin-bottom:12px">
      <div style="display:flex;align-items:center;justify-content:space-between">
        <div style="flex:1">
          <div style="font-family:'Rajdhani',sans-serif;font-size:16px;font-weight:600;margin-bottom:4px">${m.title}</div>
          <div style="font-size:12px;color:var(--text-muted)">Duration: ${m.duration}</div>
        </div>
        <span class="badge badge-${m.status==='completed'?'good':m.status==='in-progress'?'warning':'offline'}">${m.status.replace('-',' ')}</span>
      </div>
      <div class="progress-bar" style="margin-top:12px">
        <div class="progress-fill" style="width:${m.progress}%;background:${m.progress===100?'var(--accent-green)':m.progress>0?'var(--accent-cyan)':'var(--text-muted)'}"></div>
      </div>
      <div style="font-size:11px;color:var(--text-muted);margin-top:4px;font-family:'Share Tech Mono',monospace">${m.progress}% Complete</div>
      ${m.status !== 'completed' ? `<button class="btn btn-${m.status==='in-progress'?'primary':'secondary'} btn-sm" style="margin-top:12px">${m.status==='in-progress'?'▶ Continue':'▶ Start'}</button>` : '<div style="margin-top:12px;color:var(--accent-green);font-size:13px">✅ Completed</div>'}
    </div>
  `).join('');
}

// ============================================================
// TAB SWITCHING
// ============================================================
function switchTab(event, panelId) {
  const container = event.target.closest('.tab-nav').parentElement;
  container.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  container.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
  event.target.classList.add('active');
  const panel = container.querySelector('#' + panelId);
  if (panel) panel.classList.add('active');
}

// ============================================================
// INIT
// ============================================================
window.addEventListener('DOMContentLoaded', () => {
  // Nothing needed here — each page calls init on load
});

window.navigate = navigate;
window.showMachineModal = showMachineModal;
window.switchTab = switchTab;
window.loadPageData = loadPageData;
