@echo off
title IndustrialAI PredictX - Predictive Maintenance System
color 0B
cls

echo.
echo  ============================================================
echo   ______              _  _        _     _    _____
echo  ^|  __  ^| _ __  ___  ^| ^|^| ^| ___  ^| ^|_  ^| ^|  ^|  _  ^|
echo  ^| ^|__^| ^|^| '__^|/ _ \ ^| ^| ^|^| ^|/ __^| ^|  __^|^\ \/ /
echo  ^|  ____^|^| ^|  ^|  __^/ ^| ^|__^| ^|\__ \ ^|^|_    ^|  ^|
echo  ^|_^|     ^|_^|   \___^|  \____/ ^|___/  \__^|  ^|_^|
echo.
echo    IndustrialAI PredictX v4.2.1
echo    Predictive Maintenance AI Platform
echo    Siemens-Grade Industrial Intelligence
echo  ============================================================
echo.
echo  [*] Initializing system...
timeout /t 1 /nobreak >nul
echo  [*] Loading AI models...
timeout /t 1 /nobreak >nul
echo  [*] Connecting to sensor network (96 sensors)...
timeout /t 1 /nobreak >nul
echo  [*] Starting real-time data engine...
timeout /t 1 /nobreak >nul
echo  [OK] All systems operational
echo.
echo  ============================================================
echo   Opening PredictX in your default browser...
echo  ============================================================
echo.

REM Get the directory of this batch file
set "DIR=%~dp0"

REM Try to open with default browser
start "" "%DIR%index.html"

echo  [OK] Application launched!
echo.
echo  PORTALS AVAILABLE:
echo  ------------------
echo  Home Page   : index.html
echo  Login Page  : login.html
echo  Admin Portal: admin.html  (admin@predictx.io)
echo  User Portal : user.html   (tech@predictx.io)
echo.
echo  MODULES:
echo  --------
echo  ADMIN (12): Dashboard, Machine Fleet, AI Predictions,
echo              Alert Center, Sensor Data, Analytics,
echo              Maintenance Scheduler, AI Models, Reports,
echo              User Management, Audit Log, Settings
echo.
echo  USER  (12): My Dashboard, My Machines, AI Predictions,
echo              My Alerts, Live Sensors, Work Orders,
echo              My Schedule, My Reports, Fault History,
echo              Training Center, My Profile, Help & Support
echo.
echo  Press any key to exit this window...
pause >nul
