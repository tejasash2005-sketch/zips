# IndustrialAI PredictX v4.2.1
## Production-Grade Industrial Predictive Maintenance AI Platform

---

## 🚀 QUICK START
1. Double-click `START.bat` to launch (Windows)
2. Or open `index.html` directly in any browser
3. Select role (Admin or Technician) and click Authenticate

---

## 📐 ARCHITECTURE

```
predictive-maintenance/
├── index.html          # Login / Role selection
├── admin.html          # Admin Portal (12 modules)
├── user.html           # Technician Portal (12 modules)
├── START.bat           # Windows launcher
├── css/
│   └── main.css        # Industrial dark theme
└── js/
    └── app.js          # AI engine + sensor simulation
```

---

## 🔐 ACCESS

| Role          | Credentials            | Portal      |
|---------------|------------------------|-------------|
| Administrator | admin@predictx.io      | admin.html  |
| Technician    | tech@predictx.io       | user.html   |

---

## 🏭 ADMIN PORTAL — 12 MODULES

| # | Module               | Description |
|---|----------------------|-------------|
| 1 | System Dashboard     | KPIs, live charts, fleet overview |
| 2 | Machine Fleet        | All 8 machines, live sensor cards |
| 3 | AI Predictions       | LSTM+RF failure forecasts, RUL |
| 4 | Alert Center         | All alerts, acknowledge, work orders |
| 5 | Sensor Data          | 12 sensors live, stream logs, charts |
| 6 | Advanced Analytics   | OEE, MTTR, heatmaps, scatter plots |
| 7 | Maintenance Scheduler| CMMS work orders queue |
| 8 | AI Model Manager     | ROC, confusion matrix, feature importance |
| 9 | Reports & Export     | PDF/CSV/XLSX, saved reports |
|10 | User Management      | 14 users, roles, permissions |
|11 | Audit Log            | SOC2 compliant activity trail |
|12 | System Settings      | Thresholds, integrations, AI config |

---

## 🔧 TECHNICIAN PORTAL — 12 MODULES

| # | Module               | Description |
|---|----------------------|-------------|
| 1 | My Dashboard         | Personal KPIs, today's work, AI tips |
| 2 | My Machines          | Assigned machine health & live data |
| 3 | AI Predictions       | Failure forecasts for my machines |
| 4 | My Alerts            | Alerts for assigned machines |
| 5 | Live Sensors         | Real-time sensor monitoring |
| 6 | Work Orders          | Assigned WOs, priority queue |
| 7 | My Schedule          | 7-day calendar view |
| 8 | My Reports           | Personal + machine reports |
| 9 | Fault History        | Historical fault log |
|10 | Training Center      | Certification & module tracking |
|11 | My Profile           | Account settings, certifications |
|12 | Help & Support       | Docs, tickets, system status |

---

## 🤖 AI MODELS DEPLOYED

- **PredictBearing-v4**: LSTM + Random Forest Ensemble (94.7% accuracy)
- **AnomalyDetect-v2**: Isolation Forest (91.2% accuracy)
- **DegradationMap-v3**: Autoencoder (88.9% accuracy)
- **RULPredict-v1**: Gradient Boosting (92.3% accuracy)

## 📡 SENSORS SIMULATED (12 per machine × 8 machines = 96 total)

Temperature · Vibration · Pressure · RPM · Current · Noise Level
Oil Pressure · Humidity · Voltage · Flow Rate · Torque · Efficiency

## 🔌 INTEGRATIONS SIMULATED
- SCADA (OPC-UA protocol)
- CMMS (SAP PM via REST API)  
- Historian DB (OSIsoft PI Web API)
- Alerts (Twilio SMS + SendGrid Email)

---

## 🛠️ TECH STACK
- Pure HTML5 + CSS3 + Vanilla JavaScript
- No external dependencies / No Node.js required
- Canvas-based charts (zero libraries)
- Google Fonts (Rajdhani, Share Tech Mono, Exo 2)
- Works offline after first load

---

© 2026 IndustrialAI PredictX — Production Predictive Maintenance Platform
