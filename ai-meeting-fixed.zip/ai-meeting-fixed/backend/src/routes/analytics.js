module.exports = require('./_modules8to15').analyticsRouter;
